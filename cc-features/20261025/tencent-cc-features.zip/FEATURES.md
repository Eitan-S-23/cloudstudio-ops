# 腾讯容器 cc-connect 功能对齐

> 更新：2026-10-25。腾讯容器1、腾讯容器2 使用同一份功能契约，但凭证、
> Worker、启动入口和 App 名称不混用。本机脚本与更新包已对齐华为闭环；
> 本地验证不能当作两台线上已经更新的证明。

## 1. 新功能与发行边界

| 功能 | 实现位置 | 要求 |
|---|---|---|
| 单机器人 `/notify` 卡片、`/notify on`、`/notify off` | cc-connect 二进制 | 使用已确认支持该功能的发行版，并飞书实测 |
| 正常回复后全停，再自动重新武装上游监控 | 三个 Python 自愈脚本 | 使用本目录对应的新版部署包，不拿历史快照覆盖 |
| 轮次隔离、互斥与失败重试 | `codex-recovery-cycle.json`、Linux flock、逐项目进度 | 本机创建自己的状态，不复制旧容器状态 |

`attention_notify` 的全局配置与逐机器人 `/notify` 命令不是同一个验收项。
写了配置、管家有通知函数、`cc-connect --version` 能运行，都不能证明 `/notify` 可用。

截至本次查询，官方 npm `cc-connect` 最新为 `1.5.0`；华为文档的单机器人
`/notify` 来自 `+notify` fork 发行版。**发行渠道须用户明确选择**：未获授权前
保留已有二进制，不后台换 fork、不编译源码、不修改 npm 包内二进制，也不覆盖本机
全局 cc-connect。若坚持官方 npm，则 `/notify` 标注待支持，不能报全功能交付完成。

后续获批安装时先确认发行包含该功能、校验其发布校验值、备份当前二进制并记录实际
来源/版本/校验值；既有容器的程序替换及重启另需授权，重启会中断全部正在进行的对话。
不直接复制华为的 systemd/安装命令，腾讯沿用原启动脚本和 watchdog。

## 2. 正本与更新包

腾讯脚本正本是 `deploy/` 根目录的三个自愈脚本及轮换、两条卡片 helper。
Instabox 的同名文件使用 `/data/workspace`，不是腾讯正本。旧 MonkeyCode 快照只作
历史输入，不再恢复或运维旧容器，也不得覆盖本次已更新的脚本。

构建通用更新包（在本机项目根目录，输出只在项目内）：

```powershell
python -B deploy/tencent/build-cc-feature-pack.py
```

默认生成 `.local-archive/tencent-cc-update-20261025/tencent-cc-features.zip`。
包内只有脚本、回归测试、本文、脱敏种子和 `SHA256SUMS`，**不含二进制、配置凭证、
飞书会话键、轮次状态或锁**。输出已存在时拒绝覆盖，改用新的项目内 `--output-dir`。
不要把旧 `deploy-tencent.zip` 或含凭证 payload 当作这个更新包；旧包不保证新功能。

这些自愈脚本不在管家的公开自动部署清单内。更新本文、更新管家或推送其他仓库，
都不会自动把新版脚本安装到腾讯容器1、2。

## 3. 新机作业初始化

最终仍是 15 条：10 轮换、3 自愈、2 默认停用卡片任务。通用模板只有 13 条
基础种子，另外两条用 `codex-stop-heartbeat.py --install` 和
`codex-new-session.py --install` 登记；两个 `--install` 不会执行全停或 `/new`。

先在新容器建立 codex 和 codex1～9 的实际会话并写入 heartbeat 配置；在获准维护窗口
停止 cc-connect 和会自动拉起它的 watchdog，确认没有进程回写作业表，再依次执行：

1. 校验新包 `SHA256SUMS`，安装脚本到 `/workspace/cc-connect`。
2. 将脱敏 `jobs-seed.template.json` 复制为新机自己的 `jobs-seed.json`（0600）。
3. `python3 -B set-cron-session.py --target jobs-seed.json --apply`：先绑定种子会话键。
4. `python3 -B seed-cron-jobs.py --apply`：导入 13 条种子。空键会被拒绝，不能先导入再绑定。
5. `python3 -B set-cron-session.py --apply`，再执行两条卡片 `--install`。
6. `python3 -B set-cron-session.py`：确认 15 条、已一致 15、待更新 0、无跳过。
7. 加固包含会话键的文件和备份为 0600，按该容器自己的启动入口恢复服务/watchdog。

全部写入位于批准的组件根目录；运行命令显式 `cd /workspace/cc-connect`，
TMPDIR、日志及缓存也放组件内。腾讯容器1、2 不用华为的 `systemctl`。
绑定后的种子与状态仅留目标容器，不同步到公开仓库或聊天。

既有容器只更新脚本和任务文案，**不覆盖**其真实 `session_key`、enabled 状态或
正在运行的轮次进度；先读取阶段，备份并安排安全交接，不能重跑“新机初始化”清空状态。

## 4. 闭环启动与验收

探针项目仍叫 `codex`，不参与九个心跳的暂停或会话重置。只认高负载家族，
429/rate limit、模型不支持和渠道失败单独出现不触发恢复。

| 当前阶段 | 上游监控 | 恢复任务 | 正常后全停 | 心跳 |
|---|---|---|---|---|
| 种子已导入、未武装 | 停用 | 停用 | 停用 | 按本机实际状态 |
| monitoring | 启用 | 停用 | 停用 | 九个暂停，探针继续 |
| triggered | 自停交接中 | 待武装或已启用 | 停用 | 九个暂停，已确认命中，不再依赖新错误 |
| restoring | 停用 | 启用 | 停用 | 逐个恢复；失败保留进度 |
| probing | 停用 | 停用 | 启用 | 等本轮正常回复 |
| stopping | 交接中 | 停用 | 启用至交接成功 | 确认九个暂停后重新武装上游 |

新机至少一个心跳运行时先 enable“正常后全停并重新武装监控”；九个都已暂停时
才直接 enable 上游监控。API 未知或探针未运行时先排查。不要同时手动启用三条，
也不为凑验收主动触发恢复、制造报错或清空会话。

状态文件 `data/codex-recovery-cycle.json` 记录阶段、monitor_since/restore_since
及 reset_done/resumed/skipped。旧回复、旧错误和未来时间不算本轮事件；全停或
恢复交接失败会重试，同一轮不会重复清空已处理会话。三个脚本共用非阻塞
`data/codex-recovery-cycle.lock`。新机不复制这两项及 `.tmp-*`；现有状态不能随意删除。

`CC_CONNECT_DIR` 可指定批准的组件目录，默认 `/workspace/cc-connect`；
`CC_PROBE_LABEL` 可指定对应 App 实际展示名，只改文案，不改凭证或探针标识。
`CC_CONNECT_BIN` 可指定已批准的 cc-connect 程序路径，不会安装或修改二进制。

## 5. 验证与回滚

本地先运行 `python -B deploy/tests/test_recovery_loop.py`，覆盖完整两轮闭环、
部分失败、旧记录、真实备份失败、路径/展示名适配；Windows 跳过 Linux flock 项。
再运行 `python -B deploy/tests/test_cc_feature_pack.py`，验证更新包白名单、脱敏、
校验值、拒绝覆盖/项目外输出，以及卡片 helper 的只读模式。
目标容器在组件内隔离目录运行同一套测试，再检查实际 cron last_run、阶段和心跳。

只读脚本/种子预检：

```bash
cd /workspace/cc-connect
python3 -B verify-cc-features.py --scripts-only --template jobs-seed.template.json
python3 -B codex-upstream-watch.py --status
python3 -B codex-recovery-watch.py --status
python3 -B codex-restore-heartbeat.py --status
```

完整二进制预检去掉 `--scripts-only`；静态发现 `/notify` 文本仍不等于功能实测。
在各机器人飞书会话分别验证 `/notify` 卡片、on/off 状态保持、关闭某一台不影响
其他台，并检查实际通知按配置生效。不能因“版本号新”或“静态文本存在”就勾通过。

回滚前通过已有 CLI/卡片停用三条自愈，等待恢复进程结束，再还原已备份脚本。
运行中的 jobs.json/heartbeat_state.json 不直接覆盖；轮次先归档，显式选择恢复后
的心跳与任务状态。忙碌中的 Codex rollout 不用归档文件强行覆盖。
