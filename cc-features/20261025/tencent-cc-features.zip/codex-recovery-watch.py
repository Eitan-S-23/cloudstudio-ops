#!/usr/bin/env python3
"""
codex-recovery-watch.py — 探到 codex1~codex9 里"有一个心跳不再报错"后，
把 codex1~codex9 的 /heartbeat 全部停掉（等价人工发 /heartbeat stop）。
探针项目 codex 不碰；腾讯容器1、2 的实际展示名由 CC_PROBE_LABEL 指定。

判据（2026-09-23 实测确认）：
  心跳每轮先往会话历史写 1 条 user（"请继续之前的工作"），
    - 这一轮成功 → 再补 1 条 assistant；
    - 这一轮失败（上游报错）→ 只有 user，永远不写 assistant。
  实测（原容器）：codex1~9 全是 131 user / 0 assistant；探针是 144 user / 143 assistant。
  不能用心跳调度器自己的 last_error：agent 回合失败不计入（ExecuteHeartbeat 只在
  "平台不可用/会话忙"时报错，日志里 3324 completed / 0 failed）。

  只认最近 LOOKBACK_MIN 分钟且本轮恢复开始之后的正常回复。
  全停成功后自动武装上游监控，再停用自己；状态文件保存轮次与未完成的交接，
  操作失败时下轮重试，不受回复时间窗口过期影响。三个自愈脚本共用一把锁。

动作：管理 API（config.toml [management]，cc-connect 启动时拉起）
  POST /api/v1/projects/<项目>/heartbeat/pause
  等价 HeartbeatScheduler.Pause()，会持久化到 data/heartbeat_state.json。

用法：
  python3 codex-recovery-watch.py             # 检查；命中就把 9 个全停
  python3 codex-recovery-watch.py --dry-run   # 只报告，不动
  python3 codex-recovery-watch.py --status    # 只打印各项目计数/详情
"""
import contextlib
import datetime
import glob
import hashlib
import json
import os
import subprocess
import sys
import tomllib
import urllib.request

BASE = os.path.abspath(os.environ.get("CC_CONNECT_DIR") or "/workspace/cc-connect")
CONFIG   = os.path.join(BASE, "config.toml")
DATA_DIR = os.path.join(BASE, "data")
LOG      = os.path.join(BASE, "codex-recovery-watch.log")
BIN      = os.environ.get("CC_CONNECT_BIN") or os.path.join(BASE, "cc-connect")
PROJECTS = [f"codex{i}" for i in range(1, 10)]
# 只改展示名，不修改探针项目标识或飞书 App 凭证。
PROBE_LABEL = os.environ.get("CC_PROBE_LABEL") or "腾讯容器-codex"
LOOKBACK_MIN = 10          # 只看最近这么多分钟内的正常回复
HOME_PROJECT = "codex1"
SELF_MARKER = "codex-recovery-watch.py"
UPSTREAM_MARKER = "codex-upstream-watch.py"
RESTORE_MARKER = "codex-restore-heartbeat.py"

# 上游有时把错误当成"正文"返回；这些文本不算正常回复
ERROR_MARKERS = (
    "high demand",
    "temporary errors",
    "负载已经达到上限",
    "get_channel_failed",
    "不支持所选模型",
    "rate limit",
    "too many requests",
)

DRY = "--dry-run" in sys.argv
STATUS_ONLY = "--status" in sys.argv


def log(msg: str) -> None:
    line = f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
    print(line, flush=True)
    if DRY or STATUS_ONLY:
        return
    try:
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def parse_ts(ts: str):
    if not isinstance(ts, str) or not ts:
        return None
    try:
        value = datetime.datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return value if value.tzinfo is not None else None
    except ValueError:
        return None


def load_config() -> dict:
    with open(CONFIG, "rb") as fh:
        return tomllib.load(fh)


def project_cfg(cfg: dict, name: str) -> dict:
    for proj in cfg.get("projects", []):
        if proj.get("name") == name:
            return proj
    return {}


def effective_work_dir(proj: dict, name: str) -> str:
    """复刻 cc-connect：配置里的 work_dir，被 /cd 写下的 work_dir_override 覆盖"""
    wd = ((proj.get("agent") or {}).get("options") or {}).get("work_dir") or ""
    try:
        with open(os.path.join(DATA_DIR, "projects", f"{name}.state.json"), encoding="utf-8") as fh:
            override = (json.load(fh) or {}).get("work_dir_override") or ""
    except (OSError, ValueError):
        override = ""
    if override and os.path.isdir(override):
        return os.path.abspath(override)
    return os.path.abspath(wd) if wd else ""


def state_files(proj: dict, name: str) -> list:
    """<data_dir>/sessions/<项目名>_<sha256(绝对work_dir)前8位>.json；找不到就扫描全部候选"""
    wd = effective_work_dir(proj, name)
    if wd:
        fname = f"{name}_{hashlib.sha256(wd.encode()).hexdigest()[:8]}.json"
        cands = [os.path.join(DATA_DIR, "sessions", fname), os.path.join(DATA_DIR, fname)]
        hits = [p for p in cands if os.path.exists(p)]
        if hits:
            return hits
    return sorted(glob.glob(os.path.join(DATA_DIR, "sessions", f"{name}_*.json")))


def inspect(proj: dict, name: str, now, since=None):
    """活跃会话历史里「最近 LOOKBACK_MIN 分钟内的正常回复」条数 / 最新一条时间与摘要"""
    good = 0
    newest_ts, newest_txt = "", ""
    for path in state_files(proj, name):
        try:
            with open(path, encoding="utf-8") as fh:
                state = json.load(fh)
        except (OSError, ValueError):
            continue
        sessions = state.get("sessions") or {}
        for sid in (state.get("active_session") or {}).values():
            for entry in (sessions.get(sid) or {}).get("history") or []:
                if entry.get("role") != "assistant":
                    continue
                txt = (entry.get("content") or "").strip()
                if not txt or any(m.lower() in txt.lower() for m in ERROR_MARKERS):
                    continue
                ts = entry.get("timestamp") or ""
                t = parse_ts(ts)
                if (t is None or t > now or (now - t).total_seconds() > LOOKBACK_MIN * 60
                        or (since is not None and t <= since)):
                    continue          # 只看最近的，老回复不算
                good += 1
                if ts >= newest_ts:
                    newest_ts, newest_txt = ts, txt
    return good, newest_ts, newest_txt


def api(cfg: dict, method: str, path: str) -> tuple:
    """调管理 API；返回 (status, body)"""
    m = cfg.get("management") or {}
    port = m.get("port") or 9820
    token = m.get("token") or ""
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    req = urllib.request.Request(f"http://127.0.0.1:{port}/api/v1{path}", method=method, headers=headers)
    with urllib.request.urlopen(req, timeout=10) as resp:
        return resp.status, resp.read().decode("utf-8", "replace")


def running_projects(cfg: dict) -> list:
    """当前仍在跑心跳的项目（paused=false）；API 不通时按"未知"处理，返回 None"""
    running = []
    try:
        for name in PROJECTS:
            _, body = api(cfg, "GET", f"/projects/{name}/heartbeat/status")
            paused = json.loads(body)["data"]["paused"]
            if not isinstance(paused, bool):
                raise ValueError(f"{name}: paused 不是布尔值")
            if not paused:
                running.append(name)
    except Exception as exc:  # noqa: BLE001
        log(f"读取心跳状态失败：{exc}")
        return None
    return running


def pause_all(cfg: dict) -> int:
    """把 9 个项目的心跳全停；返回失败个数"""
    failed = 0
    for name in PROJECTS:
        try:
            status, body = api(cfg, "POST", f"/projects/{name}/heartbeat/pause")
            log(f"[{name}] pause -> {status} {body.strip()[:80]}")
            if not 200 <= status < 300:
                failed += 1
        except Exception as exc:  # noqa: BLE001 —— 网络/HTTP 错误都要落到日志
            log(f"[{name}] pause 失败：{exc}")
            failed += 1
    return failed


def session_key(cfg: dict, name: str) -> str:
    """从 cron 任务表里取该项目的飞书会话 key（用于发通知）"""
    try:
        with open(os.path.join(DATA_DIR, "crons", "jobs.json"), encoding="utf-8") as fh:
            d = json.load(fh)
    except (OSError, ValueError):
        return ""
    jobs = d if isinstance(d, list) else d.get("jobs", [])
    for job in jobs:
        if job.get("project") == name and job.get("session_key"):
            return job["session_key"]
    return ""


def notify(cfg: dict, text: str) -> None:
    """在 9 个项目的飞书会话里各发一条（失败了不影响主流程）"""
    for name in PROJECTS:
        key = session_key(cfg, name)
        if not key:
            continue
        try:
            subprocess.run([BIN, "send", "-p", name, "-s", key, "-m", text],
                           capture_output=True, timeout=5, cwd=os.path.dirname(CONFIG),
                           env=dict(os.environ, CC_DATA_DIR=DATA_DIR))
        except Exception as exc:  # noqa: BLE001
            log(f"[{name}] 通知发送失败：{exc}")


def cron_jobs() -> list:
    try:
        with open(os.path.join(DATA_DIR, "crons", "jobs.json"), encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, list) else d.get("jobs", [])
    except (OSError, ValueError):
        return []


def find_job(marker: str):
    jobs = [j for j in cron_jobs() if j.get("project") == HOME_PROJECT
            and marker in (j.get("exec") or "")]
    return jobs[0] if len(jobs) == 1 else None


def cron_edit(cfg: dict, job: dict, enabled: bool) -> bool:
    """通过现有 CLI 修改，并回读任务表确认；不直接改 jobs.json。"""
    current = next((j for j in cron_jobs() if j.get("id") == job["id"]), None)
    if not current or current.get("project") != HOME_PROJECT:
        return False
    if current.get("enabled") is enabled:
        return True
    env = dict(os.environ, CC_PROJECT=HOME_PROJECT,
               CC_SESSION_KEY=session_key(cfg, HOME_PROJECT), CC_DATA_DIR=DATA_DIR)
    try:
        result = subprocess.run([BIN, "cron", "edit", str(job["id"]), "enabled",
                                 str(enabled).lower()], capture_output=True, timeout=15,
                                cwd=os.path.dirname(CONFIG), env=env)
        confirmed = next((j for j in cron_jobs() if j.get("id") == job["id"]), {})
        ok = result.returncode == 0 and confirmed.get("enabled") is enabled
        log(f"cron edit {job['id']} enabled={enabled} -> rc={result.returncode} confirmed={ok}")
        return ok
    except (OSError, subprocess.SubprocessError) as exc:
        log(f"cron edit {job['id']} 失败：{exc}")
        return False


def load_cycle() -> dict:
    try:
        with open(os.path.join(DATA_DIR, "codex-recovery-cycle.json"), encoding="utf-8") as fh:
            state = json.load(fh)
    except FileNotFoundError:
        return {}
    phases = ("monitoring", "triggered", "restoring", "probing", "stopping")
    if not isinstance(state, dict) or state.get("phase") not in phases:
        raise ValueError("闭环状态文件无效，拒绝猜测当前轮次")
    for key in ("monitor_since", "restore_since"):
        if key in state and parse_ts(state[key]) is None:
            raise ValueError(f"闭环状态 {key} 无效")
    if state["phase"] in ("monitoring", "stopping") and "monitor_since" not in state:
        raise ValueError("闭环状态缺少 monitor_since")
    if state["phase"] in ("restoring", "probing") and "restore_since" not in state:
        raise ValueError("闭环状态缺少 restore_since")
    for key in ("reset_done", "resumed", "skipped"):
        if key in state and (not isinstance(state[key], list)
                             or any(name not in PROJECTS for name in state[key])):
            raise ValueError(f"闭环进度 {key} 无效")
    return state


def save_cycle(state: dict) -> None:
    path = os.path.join(DATA_DIR, "codex-recovery-cycle.json")
    tmp = path + f".tmp-{os.getpid()}"
    try:
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(state, fh, ensure_ascii=False, indent=2)
            fh.write("\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


@contextlib.contextmanager
def cycle_lock():
    import fcntl

    with open(os.path.join(DATA_DIR, "codex-recovery-cycle.lock"), "a") as fh:
        try:
            fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            log("其他自愈任务正在交接，本轮跳过")
            yield False
            return
        try:
            yield True
        finally:
            fcntl.flock(fh, fcntl.LOCK_UN)


def disable_self(cfg: dict) -> bool:
    job = find_job(SELF_MARKER)
    return bool(job and cron_edit(cfg, job, False))


def run() -> int:
    cfg = load_config()
    now = datetime.datetime.now(datetime.UTC)
    cycle = load_cycle()
    since = parse_ts(cycle.get("restore_since", ""))

    marks, hits = [], []
    for name in PROJECTS:
        good, ts, txt = inspect(project_cfg(cfg, name), name, now, since)
        marks.append(f"{name}={good}")
        if good:
            hits.append((name, good, ts, txt))

    log(f"近 {LOOKBACK_MIN} 分钟计数 " + " ".join(marks)
        + ("  ← 命中: " + ", ".join(h[0] for h in hits) if hits else "  等待中"))

    if STATUS_ONLY:
        for name, good, ts, txt in hits:
            log(f"[{name}] 正常回复 {good} 条，最后一条 {ts}：{txt[:120]}")
        running = running_projects(cfg)
        label = "状态未知" if running is None else (", ".join(running) or "（全部已停）")
        log("当前运行中的心跳：" + label)
        return 0

    running = running_projects(cfg)
    restore = find_job(RESTORE_MARKER)
    upstream = find_job(UPSTREAM_MARKER)
    if not restore or not upstream or not find_job(SELF_MARKER):
        log("三条自愈任务缺失或重复，保留自身等待修复")
        return 1
    if restore.get("enabled") or cycle.get("phase") in ("triggered", "restoring"):
        log("一键恢复尚未交接完成，暂不停止心跳")
        return 0
    if DRY:
        log(f"DRY-RUN: phase={cycle.get('phase', 'legacy')} hits={len(hits)}；"
            "命中或未完成交接时会全停、重新武装上游监控并停用自己")
        return 0
    if running is None:
        return 1
    if cycle.get("phase") == "monitoring" and not running:
        # 自停失败后的重试不能推进监控时间边界，否则会漏掉刚发生的错误。
        return 0 if cron_edit(cfg, upstream, True) and disable_self(cfg) else 1
    if cycle.get("phase") != "stopping":
        if not hits:
            return 0
        cycle = {"phase": "stopping", "monitor_since": now.isoformat()}
        save_cycle(cycle)
    if running and pause_all(cfg):
        log("部分心跳暂停失败，保留交接状态，下轮重试")
        return 1
    confirmed = running_projects(cfg)
    if confirmed is None or confirmed:
        log("未确认九个心跳全部停止，下轮重试")
        return 1
    if not cron_edit(cfg, upstream, True):
        log("上游监控武装失败，保留交接状态，下轮重试")
        return 1
    cycle["phase"] = "monitoring"
    save_cycle(cycle)
    if not disable_self(cfg):
        return 1
    notify(cfg, "⏹ 检测到心跳已恢复正常回复，已按规则停止 codex1~codex9 的心跳"
                f"（等同 /heartbeat stop）。{PROBE_LABEL} 不受影响。"
                "上游高负载监控已自动重新武装，下次命中会自动恢复心跳。")
    log("全部 9 个心跳已停止，上游监控已重新武装，自身已停用")
    return 0


def main() -> int:
    try:
        if DRY or STATUS_ONLY:
            return run()
        with cycle_lock() as acquired:
            return run() if acquired else 0
    except (OSError, ValueError) as exc:
        log(f"闭环检查失败，保留任务等待重试：{exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
