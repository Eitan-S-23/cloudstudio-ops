#!/usr/bin/env python3
"""
codex-restore-heartbeat.py — 一键恢复 codex1~codex9 的心跳（在 codex1 的 /cron 卡片点 enable 即执行）

做四件事（对腾讯容器的 codex1~codex9 逐个处理，探针项目 codex 不碰）：
  1. 重置会话：把每个项目「活跃会话」的 codex thread 文件截断到只剩 session_meta
     （等价 /new，零停机；整份备份到 session-archive/<日期>/，可用日志里的 cp 命令回滚）。
     老线程现在带着 invalid_encrypted_content 400，不重置的话恢复心跳也是白报错。
     有 codex 进程正用着该 CODEX_HOME 时跳过重置（避免打断进行中的一轮），仍会恢复心跳。
  2. 恢复心跳：POST /api/v1/projects/<项目>/heartbeat/resume（等价 /heartbeat start）。
     从 codex1 开始逐个恢复，每个之间隔 STAGGER_SECS 秒（默认 6），避免 9 个心跳同时打上游。
  3. 重新武装监控：把「一恢复正常就全停」的那条 cron（exec 里含 codex-recovery-watch.py）
     重新 enable，形成闭环。
  4. 全部恢复并确认监控武装成功后才自停；失败保留进度，下轮自动重试。
     已处理过的项目不会在重试时重复清空会话。正常后全停任务会重新武装上游监控。

复用 rotate-codex-session.py 里已验证的清空/备份/忙碌检测逻辑（按文件路径加载，不复制代码）。

用法：
  python3 codex-restore-heartbeat.py             # 执行恢复
  python3 codex-restore-heartbeat.py --dry-run   # 只打印将要做什么，不动
  python3 codex-restore-heartbeat.py --status    # 只看当前心跳/线程状态
"""
import datetime
import importlib.util
import json
import os
import subprocess
import sys
import time
import tomllib
import urllib.request

BASE = os.path.abspath(os.environ.get("CC_CONNECT_DIR") or "/workspace/cc-connect")
CONFIG       = os.path.join(BASE, "config.toml")
DATA_DIR     = os.path.join(BASE, "data")
LOG          = os.path.join(BASE, "codex-restore-heartbeat.log")
BIN          = os.environ.get("CC_CONNECT_BIN") or os.path.join(BASE, "cc-connect")
ROTATE_PY    = os.path.join(BASE, "rotate-codex-session.py")
WATCH_PY     = os.path.join(BASE, "codex-recovery-watch.py")
ARCHIVE_ROOT = os.path.join(BASE, "session-archive")
PROJECTS     = [f"codex{i}" for i in range(1, 10)]
STAGGER_SECS = 6                             # 逐个恢复之间的间隔，避免 9 个心跳同时打上游
WATCH_MARKER = "codex-recovery-watch.py"     # 要重新武装的监控任务
SELF_MARKER  = "codex-restore-heartbeat.py"  # 本脚本自己的任务

DRY = "--dry-run" in sys.argv
STATUS_ONLY = "--status" in sys.argv


def load_rotate():
    """按路径加载 rotate-codex-session.py，复用它已验证的清空/备份/忙碌检测函数"""
    spec = importlib.util.spec_from_file_location("rotate_codex_session", ROTATE_PY)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.LOG = LOG      # 让它的日志并到本脚本的日志里
    mod.DRY = DRY
    mod.CONFIG = CONFIG
    mod.DATA_DIR = DATA_DIR
    mod.ARCHIVE_ROOT = ARCHIVE_ROOT
    return mod


def log(msg: str) -> None:
    line = f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
    print(line, flush=True)
    if DRY or STATUS_ONLY:
        return
    try:
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def load_config() -> dict:
    with open(CONFIG, "rb") as fh:
        return tomllib.load(fh)


def project_cfg(cfg: dict, name: str) -> dict:
    for proj in cfg.get("projects", []):
        if proj.get("name") == name:
            return proj
    return {}


def api(cfg: dict, method: str, path: str) -> tuple:
    m = cfg.get("management") or {}
    port = m.get("port") or 9820
    token = m.get("token") or ""
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    req = urllib.request.Request(f"http://127.0.0.1:{port}/api/v1{path}", method=method, headers=headers)
    with urllib.request.urlopen(req, timeout=10) as resp:
        return resp.status, resp.read().decode("utf-8", "replace")


def heartbeat_paused(cfg: dict, name: str):
    """True/False；API 不通时返回 None"""
    try:
        _, body = api(cfg, "GET", f"/projects/{name}/heartbeat/status")
        value = json.loads(body)["data"]["paused"]
        return value if isinstance(value, bool) else None
    except Exception:  # noqa: BLE001
        return None


def resume_heartbeat(cfg: dict, name: str) -> bool:
    try:
        status, _ = api(cfg, "POST", f"/projects/{name}/heartbeat/resume")
        log(f"[{name}] resume -> {status}")
        return 200 <= status < 300
    except Exception as exc:  # noqa: BLE001
        log(f"[{name}] resume 失败：{exc}")
        return False


def cron_jobs() -> list:
    try:
        with open(os.path.join(DATA_DIR, "crons", "jobs.json"), encoding="utf-8") as fh:
            d = json.load(fh)
    except (OSError, ValueError):
        return []
    return d if isinstance(d, list) else d.get("jobs", [])


def session_key(name: str) -> str:
    """从 cron 任务表里取该项目的飞书会话 key（用于发通知/给 CLI 定项目）"""
    for job in cron_jobs():
        if job.get("project") == name and job.get("session_key"):
            return job["session_key"]
    return ""


def notify(text: str) -> None:
    for name in PROJECTS:
        key = session_key(name)
        if not key:
            continue
        try:
            subprocess.run([BIN, "send", "-p", name, "-s", key, "-m", text],
                           capture_output=True, timeout=5, cwd=os.path.dirname(CONFIG),
                           env=dict(os.environ, CC_DATA_DIR=DATA_DIR))
        except Exception as exc:  # noqa: BLE001
            log(f"[{name}] 通知发送失败：{exc}")


def load_watch():
    spec = importlib.util.spec_from_file_location("codex_recovery_watch", WATCH_PY)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.LOG = LOG
    mod.DRY = DRY
    mod.STATUS_ONLY = STATUS_ONLY
    return mod


def rotate_checked(rot, proj: dict, name: str) -> tuple:
    """旧归档函数可能吞掉文件错误；回验原本有上下文的 thread 后才承认完成。"""
    pending = set()
    home = rot.codex_home(proj)
    for state_path in rot.state_files(proj, name):
        with open(state_path, encoding="utf-8") as fh:
            state = json.load(fh)
        sessions = state.get("sessions") or {}
        for sid in (state.get("active_session") or {}).values():
            agent_sid = (sessions.get(sid) or {}).get("agent_session_id")
            path = rot.find_rollout(home, agent_sid) if agent_sid else ""
            if not path:
                continue
            with open(path, "rb") as fh:
                first, rest = fh.readline(), fh.read()
            if rest.strip():
                if json.loads(first).get("type") != "session_meta":
                    raise ValueError(f"{name}: thread 缺少 session_meta，拒绝重置")
                pending.add(path)
    rc, busy = rot.rotate_one(name)
    if rc or busy:
        return rc, busy
    for path in pending:
        with open(path, "rb") as fh:
            first, rest = fh.readline(), fh.read()
        if rest.strip() or json.loads(first).get("type") != "session_meta":
            raise OSError(f"{name}: thread 重置未完成，保留任务重试")
    return 0, False


def run(mod) -> int:
    rot = load_rotate()
    cfg = load_config()

    if STATUS_ONLY:
        for name in PROJECTS:
            proj = project_cfg(cfg, name)
            home = rot.codex_home(proj)
            paused = heartbeat_paused(cfg, name)
            busy = rot.codex_busy(home) if home else ""
            state = "已停" if paused else ("运行中" if paused is False else "未知")
            log(f"[{name}] 心跳={state} codex_home={home or '未配置'}"
                + (f" 正被 pid={busy} 占用" if busy else ""))
        return 0

    if DRY:
        log(f"DRY-RUN：将从 codex1 开始逐个重置会话并恢复心跳，每个间隔 {STAGGER_SECS} 秒：")
        for name in PROJECTS:
            proj = project_cfg(cfg, name)
            home = rot.codex_home(proj)
            busy = rot.codex_busy(home) if home else ""
            log(f"  {name}: 重置会话{'（跳过：正被 pid=' + busy + ' 占用）' if busy else ''} + resume 心跳"
                + f" → 等 {STAGGER_SECS}s")
        log("DRY-RUN：随后会重新武装监控任务并停用自己")
        return 0

    watch = mod.find_job(WATCH_MARKER)
    me = mod.find_job(SELF_MARKER)
    upstream = mod.find_job(mod.UPSTREAM_MARKER)
    if not watch or not me or not upstream:
        log("三条自愈任务缺失或重复，本轮不动")
        return 1
    cycle = mod.load_cycle()
    if cycle.get("phase") not in ("restoring", "probing"):
        cycle = {"phase": "restoring", "restore_since": datetime.datetime.now(
            datetime.UTC).isoformat(), "reset_done": [], "resumed": [], "skipped": []}
        mod.save_cycle(cycle)
    if not mod.cron_edit(cfg, watch, False) or not mod.cron_edit(cfg, upstream, False):
        log("未能停用其他监控，保留恢复任务，下轮重试")
        return 1

    total = (len(PROJECTS) - 1) * STAGGER_SECS
    log(f"开始逐个恢复：codex1 → codex9，每个间隔 {STAGGER_SECS} 秒（约 {total} 秒）")

    failed = []
    skipped = cycle.setdefault("skipped", [])
    reset_done = cycle.setdefault("reset_done", [])
    resumed = cycle.setdefault("resumed", [])
    for idx, name in enumerate(PROJECTS):
        if name in resumed and heartbeat_paused(cfg, name) is False:
            continue
        if heartbeat_paused(cfg, name) is None:
            log(f"[{name}] 状态未知，不清空、不恢复，下轮重试")
            failed.append(name)
            continue
        proj = project_cfg(cfg, name)
        home = rot.codex_home(proj)
        if name not in reset_done:
            if not home or not os.path.isdir(home):
                log(f"[{name}] codex_home 不存在，跳过重置")
                skipped.append(name)
            elif rot.codex_busy(home):
                log(f"[{name}] 有 codex 进程占用，本轮跳过重置（只恢复心跳）")
                skipped.append(name)
            else:
                try:
                    rc, busy = rotate_checked(rot, proj, name)
                except (OSError, ValueError) as exc:
                    log(f"[{name}] 会话重置失败：{exc}")
                    failed.append(name)
                    continue
                if rc:
                    failed.append(name)
                    continue
                if busy:
                    skipped.append(name)
            reset_done.append(name)
            mod.save_cycle(cycle)
        if not resume_heartbeat(cfg, name) or heartbeat_paused(cfg, name) is not False:
            failed.append(name)
        else:
            if name not in resumed:
                resumed.append(name)
            mod.save_cycle(cycle)
        if idx < len(PROJECTS) - 1:
            log(f"[{name}] 已恢复，{STAGGER_SECS} 秒后恢复 {PROJECTS[idx + 1]}")
            time.sleep(STAGGER_SECS)

    if failed:
        log(f"恢复未完成：{', '.join(failed)}；保留进度，下轮自动重试")
        return 1
    if any(heartbeat_paused(cfg, name) is not False for name in PROJECTS):
        log("未确认全部九个心跳运行中，下轮重试")
        return 1
    cycle["phase"] = "probing"
    mod.save_cycle(cycle)
    if not mod.cron_edit(cfg, watch, True):
        log("正常回复监控武装失败，保留恢复任务，下轮只重试交接")
        return 1
    if not mod.cron_edit(cfg, me, False):
        log("恢复任务自停失败，下轮只重试交接")
        return 1

    reset_note = "会话已重置为全新线程（旧上下文备份在 session-archive）"
    if skipped:
        reset_note = (f"会话已重置为全新线程（旧上下文备份在 session-archive）；"
                      f"但 {'、'.join(skipped)} 当时正忙、这次没重置，先用旧上下文跑，下个整点会自动清空")
    tail = "监控已重新武装：任一项目恢复正常回复后自动全停，再自动武装上游高负载监控。"
    notify("▶️ 已一键恢复 codex1~codex9 的心跳。" + reset_note + "。" + tail)

    log(f"完成：{len(PROJECTS) - len(failed)}/{len(PROJECTS)} 个心跳已恢复"
        + (f"，失败：{', '.join(failed)}" if failed else ""))
    return 1 if failed else 0


def main() -> int:
    mod = load_watch()
    try:
        if DRY or STATUS_ONLY:
            return run(mod)
        with mod.cycle_lock() as acquired:
            return run(mod) if acquired else 0
    except (OSError, ValueError) as exc:
        log(f"闭环恢复失败，保留任务等待重试：{exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
