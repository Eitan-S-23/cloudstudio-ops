#!/usr/bin/env python3
"""
codex-upstream-watch.py — 盯腾讯容器常驻探针项目 codex 的回复:一旦确认上游回的是
"高负载"(We're currently experiencing high demand, which may cause temporary errors.
这一类),就自动武装「一键恢复」那条 cron(codex-restore-heartbeat.py),由它去重置
会话、恢复 codex1~codex9 的心跳;然后把自己停掉。心跳恢复正常并全停后，
codex-recovery-watch.py 会自动重新武装本监控，形成闭环。

只认高负载,不认节流(2026-09-28 用户明确要求):rate limit exceeded / 429 Too Many
Requests / exceeded retry limit / 400 / 不支持所选模型 / get_channel_failed / resource
temporarily blocked 这些统统不触发。别改回去用 codex-recovery-watch.py 的
ERROR_MARKERS —— 那是"这条回复是不是正常回复"的宽列表,含 rate limit,用途不一样。

为什么盯探针:codex1~9 的心跳被「一恢复正常就全停」那条 cron 停掉之后就在
装死,这时唯一还在持续打上游的是常驻探针项目 codex(原容器里每 3 分钟一轮心跳、
专门当探针;称呼见下方 PROBE_LABEL)。

两条命中路径:
  ① 回复正文里就是高负载文案(上游有时把错误当正文返回)——会话历史里直接看得见;
  ② 这一轮压根没回复(失败只写一条 user、不写 assistant)——错误文本本身只落在
     cc.log 的 "agent error" / "codexSession: turn failed" 行里,且那些行不带项目
     标注,所以要拿心跳 user 的时间戳去 cc.log 对齐 [t, t+FAIL_WINDOW_SECS] 窗口,
     窗口里出现高负载家族的报错才算命中。这一步同时把 rate limit 挡在外面。
只认最近 LOOKBACK_MIN 分钟内的动向,老账不算;你自己发的长任务不算(只看心跳轮)。

动手前的前置条件(避免重复恢复):
  - codex1~codex9 心跳当前"全部已停"(只要还有一个在跑,说明已经在探测状态了);
  - 「一键恢复」cron 当前停用(已经 enable 的不抢,让它自己跑完)。
  任一不满足就静默跳过,下一分钟再看。

用法:
  python3 codex-upstream-watch.py             # 检查;命中就武装一键恢复并停用自己
  python3 codex-upstream-watch.py --dry-run   # 只报告,不动
  python3 codex-upstream-watch.py --status    # 打印判据明细与相关任务状态
"""
import datetime
import importlib.util
import json
import os
import re
import subprocess
import sys

BASE = os.path.abspath(os.environ.get("CC_CONNECT_DIR") or "/workspace/cc-connect")
CONFIG         = os.path.join(BASE, "config.toml")
DATA_DIR       = os.path.join(BASE, "data")
LOG            = os.path.join(BASE, "codex-upstream-watch.log")
CC_LOG         = os.path.join(BASE, "cc.log")
BIN            = os.environ.get("CC_CONNECT_BIN") or os.path.join(BASE, "cc-connect")
WATCH_SCRIPT   = os.path.join(BASE, "codex-recovery-watch.py")
PROBE_PROJECT  = "codex"                       # 常驻探针项目
# 腾讯容器1、2 可分别设置实际 App 展示名。
PROBE_LABEL    = os.environ.get("CC_PROBE_LABEL") or "腾讯容器-codex"
HOME_PROJECT   = "codex1"                      # 通知与 cron 归属的项目
RESTORE_MARKER = "codex-restore-heartbeat.py"  # 要武装的「一键恢复」任务
SELF_MARKER    = "codex-upstream-watch.py"     # 本脚本自己的任务
LOOKBACK_MIN         = 20     # 只看最近这么多分钟内的动向
GRACE_HEARTBEAT_SECS = 120    # 心跳轮多久没回复才算"这轮挂了"(正常 5~30 秒)
FAIL_WINDOW_SECS     = 180    # 心跳 user 之后多久之内的报错算这一轮的
TAIL_BYTES           = 4 * 1024 * 1024   # cc.log 每次只读尾部这么多(实测 20 分钟约 0.04MB)

# 高负载家族(命中即触发)。加词只加"上游过载/高负载"这一类;
# rate limit、429、retry limit、400、模型不支持、渠道失败都不属于这里。
HIGH_LOAD_MARKERS = (
    "high demand",          # 经典文案:We're currently experiencing high demand…
    "temporary errors",     # 同一句的后半段,其他上游的近似文案
    "负载已经达到上限",       # 中文上游的同类过载文案
)

# cc.log 里代表"上游这一轮报错"的日志行(错误文本在 error= / message= 字段)
ERROR_MSGS = ("codexSession: turn failed", "agent error", "codexSession: error event")
LINE_RE = re.compile(r'^time=(\S+) level=(\w+) msg="([^"]*)"(.*)$')
VALUE_RE = re.compile(r'(?:error|message)="(.*)"\s*$')

DRY = "--dry-run" in sys.argv
STATUS_ONLY = "--status" in sys.argv


def log(msg: str) -> None:
    line = f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
    print(line, flush=True)
    if DRY or STATUS_ONLY:
        return
    try:
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def load_watch():
    """按路径加载 codex-recovery-watch.py,复用它已验证的配置/会话/管理 API 逻辑"""
    spec = importlib.util.spec_from_file_location("codex_recovery_watch", WATCH_SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.LOG = LOG            # 让它的日志并到本脚本的日志里
    mod.DRY = DRY
    mod.STATUS_ONLY = STATUS_ONLY
    return mod


def cron_jobs() -> list:
    try:
        with open(os.path.join(DATA_DIR, "crons", "jobs.json"), encoding="utf-8") as fh:
            d = json.load(fh)
    except (OSError, ValueError):
        return []
    return d if isinstance(d, list) else d.get("jobs", [])


def home_session_key() -> str:
    """从 cron 任务表里取 codex1 的飞书会话 key(发通知、给 CLI 定项目用)"""
    for job in cron_jobs():
        if job.get("project") == HOME_PROJECT and job.get("session_key"):
            return job["session_key"]
    return ""


def notify(text: str) -> None:
    key = home_session_key()
    if not key:
        log("找不到 codex1 的会话 key,通知没发出去")
        return
    try:
        subprocess.run([BIN, "send", "-p", HOME_PROJECT, "-s", key, "-m", text],
                       capture_output=True, timeout=5, cwd=os.path.dirname(CONFIG),
                       env=dict(os.environ, CC_DATA_DIR=DATA_DIR))
    except Exception as exc:  # noqa: BLE001
        log(f"通知发送失败:{exc}")


def is_high_load(text: str) -> bool:
    low = text.lower()
    return any(m.lower() in low for m in HIGH_LOAD_MARKERS)


def history_entries(mod, cfg):
    """探针项目活跃会话的历史条目(逐份 state 文件产出)"""
    proj = mod.project_cfg(cfg, PROBE_PROJECT)
    for path in mod.state_files(proj, PROBE_PROJECT):
        try:
            with open(path, encoding="utf-8") as fh:
                state = json.load(fh)
        except (OSError, ValueError):
            continue
        sessions = state.get("sessions") or {}
        for sid in (state.get("active_session") or {}).values():
            yield os.path.basename(path), (sessions.get(sid) or {}).get("history") or []


def check_reply_body(mod, history, now, since=None):
    """路径①:最近一条 assistant 回复的正文里就是高负载文案"""
    cutoff = now - datetime.timedelta(minutes=LOOKBACK_MIN)
    last_assistant = next((e for e in reversed(history) if e.get("role") == "assistant"), None)
    if last_assistant is None:
        return None
    t = mod.parse_ts(last_assistant.get("timestamp") or "")
    if t is None or t < cutoff or t > now or (since is not None and t <= since):
        return None
    text = (last_assistant.get("content") or "").strip()
    return f"回复正文含高负载文案:{text[:60]}" if text and is_high_load(text) else None


def check_failed_heartbeat(mod, history, now, prompt, since=None):
    """路径②第一步:最近一条心跳 user 是否"挂了";返回 (挂了的时间 or None, 说明)"""
    cutoff = now - datetime.timedelta(minutes=LOOKBACK_MIN)
    for idx in range(len(history) - 1, -1, -1):
        entry = history[idx]
        if entry.get("role") != "user":
            continue
        # 只看心跳轮:你自己发的消息可能跑很久,也不能算上游报错
        if not prompt or (entry.get("content") or "").strip() != prompt:
            return None, "最近一条是真人消息,不判"
        t = mod.parse_ts(entry.get("timestamp") or "")
        if t is None or t < cutoff or t > now or (since is not None and t <= since):
            return None, "最近的心跳太老,不看"
        age = (now - t).total_seconds()
        if age < GRACE_HEARTBEAT_SECS:
            return None, f"心跳 {age:.0f} 秒前刚发出,还在跑"
        if any(e.get("role") == "assistant" and (e.get("content") or "").strip()
               for e in history[idx + 1:]):
            return None, "最近一轮心跳有正常回复"
        return t, f"心跳轮 {age / 60:.0f} 分钟没有回复({t:%H:%M:%S} 那条 user)"
    return None, "历史里没有心跳记录"


def log_errors_between(mod, start, end):
    """cc.log 尾部里 [start, end] 窗口内的上游报错行;返回 (去重后的 [(时间, 文本)], 尾部最早时间)"""
    try:
        with open(CC_LOG, "rb") as fh:
            size = fh.seek(0, os.SEEK_END)
            fh.seek(max(0, size - TAIL_BYTES))
            data = fh.read().decode("utf-8", "replace")
    except OSError:
        return [], None
    if not data.startswith("time="):
        data = data.split("\n", 1)[-1]        # 丢掉被tail截断的首行
    earliest, seen, out = None, set(), []
    for line in data.splitlines():
        m = LINE_RE.match(line)
        if not m:
            continue
        ts, _, msg, rest = m.groups()
        t = mod.parse_ts(ts)
        if t is None:
            continue
        if earliest is None or t < earliest:
            earliest = t
        if msg not in ERROR_MSGS or not (start <= t <= end):
            continue
        v = VALUE_RE.search(" " + rest)
        if not v:
            continue
        text = re.sub(r"\s+", " ", v.group(1)).strip()
        if text and text not in seen:
            seen.add(text)
            out.append((t, text))
    return out, earliest


def detect(mod, cfg, now, since=None):
    """返回 (是否命中, 说明);路径①先看,路径②要走日志核对"""
    prompt = ((mod.project_cfg(cfg, PROBE_PROJECT).get("heartbeat") or {}).get("prompt") or "").strip()
    notes = []
    for name, history in history_entries(mod, cfg):
        body = check_reply_body(mod, history, now, since)
        if body:
            return True, f"{name}:{body}", notes
        failed_at, why = check_failed_heartbeat(mod, history, now, prompt, since)
        notes.append(f"{name}:{why}")
        if failed_at is None:
            continue
        end = min(now, failed_at + datetime.timedelta(seconds=FAIL_WINDOW_SECS))
        errors, earliest = log_errors_between(mod, failed_at, end)
        if earliest is not None and earliest > failed_at + datetime.timedelta(seconds=60):
            notes.append("cc.log 尾部覆盖不到这一轮,本轮不判")
            continue
        if not errors:
            notes.append("cc.log 同窗口没有报错行")
            continue
        hit = next(((t, txt) for t, txt in errors if is_high_load(txt)), None)
        if hit:
            return True, (f"{name}:{why},cc.log 在 {hit[0]:%H:%M:%S} 是高负载报错:{hit[1][:60]}"), notes
        notes.append("这一轮的报错不属于高负载家族(不触发),cc.log 里是:" +
                     "; ".join(f"{t:%H:%M:%S} {txt[:60]}" for t, txt in errors[:3]))
    return False, "", notes


def run(mod) -> int:
    cfg = mod.load_config()
    now = datetime.datetime.now(datetime.UTC)
    cycle = mod.load_cycle()
    since = mod.parse_ts(cycle.get("monitor_since", ""))

    hit, detail, notes = detect(mod, cfg, now, since)
    restore = mod.find_job(RESTORE_MARKER)
    me = mod.find_job(SELF_MARKER)
    running = mod.running_projects(cfg)
    running_txt = ", ".join(running) if running else ("全部已停" if running == [] else "状态未知")

    if STATUS_ONLY:
        log(f"{PROBE_LABEL} 判据:{detail if hit else '无高负载报错'}")
        for note in notes:
            log(f"  · {note}")
        log(f"codex1~9 心跳:{running_txt}")
        log("一键恢复任务:" + (f"{restore['id']} enabled={restore.get('enabled')}"
                              if restore else "未找到"))
        log("本监控任务:" + (f"{me['id']} enabled={me.get('enabled')}" if me else "未找到"))
        return 0

    if not restore or not me:
        log("恢复任务或本监控任务缺失/重复，本轮不动")
        return 1
    if restore.get("enabled"):
        log("一键恢复已启用，不重复触发；完成上游监控自停交接")
        return 0 if DRY or mod.cron_edit(cfg, me, False) else 1
    if cycle.get("phase") in ("restoring", "probing", "stopping"):
        log("恢复/停止任务正在交接，本轮不触发")
        return 0
    if not hit and cycle.get("phase") != "triggered":
        log(f"等待中:{PROBE_LABEL} 无高负载报错(" + "; ".join(notes) + f"; 心跳 {running_txt})")
        return 0

    log(f"命中:{detail}")
    if running is None:
        log("管理 API 读不到心跳状态,本轮不动(下一分钟再看)")
        return 1
    if running:
        log(f"{running_txt} 的心跳仍在跑(已在探测状态),无需恢复")
        return 0
    if DRY:
        log(f"DRY-RUN:会武装「一键恢复」{restore['id']},然后停用自己")
        return 0

    cycle["phase"] = "triggered"
    cycle.setdefault("monitor_since", now.isoformat())
    mod.save_cycle(cycle)
    if not mod.cron_edit(cfg, restore, True):
        log("武装「一键恢复」失败,本轮不动(下一分钟重试)")
        return 1
    log(f"已武装「一键恢复」{restore['id']}(它会在 1 分钟内自己跑起来)")
    if not mod.cron_edit(cfg, me, False):
        log("恢复已武装，但监控自停失败，下轮只重试交接")
        return 1
    notify(f"⚠️ 监控到 {PROBE_LABEL} 的上游回的是高负载报错({detail}),已自动武装「一键恢复」,"
           f"它会在 1 分钟内重置会话并恢复 codex1~codex9 的心跳。\n"
           "本监控已停用；心跳恢复正常并全停后会自动重新武装，无需手动 enable。")
    log("完成:已武装一键恢复,并停用自己")
    return 0


def main() -> int:
    mod = load_watch()
    try:
        if DRY or STATUS_ONLY:
            return run(mod)
        with mod.cycle_lock() as acquired:
            return run(mod) if acquired else 0
    except (OSError, ValueError) as exc:
        log(f"闭环监控失败，保留任务等待重试：{exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
