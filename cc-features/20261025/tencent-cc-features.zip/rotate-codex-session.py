#!/usr/bin/env python3
"""
rotate-codex-session.py — 定时清空 codex 会话上下文（等价于 /new，零停机）

原理（已验证，2026-09-20）：
  1. 从 cc-connect 的会话状态里读出 codex 项目"当前活跃会话"的 agent_session_id
  2. 找到对应的 codex thread 文件 <codex_home>/sessions/*/*/*/rollout-*<id>.jsonl
  3. 整份复制到归档目录（可回滚），然后把原文件截断到只剩第 1 行 session_meta
  4. 下一次唤醒该 thread 时，codex resume 照常成功，但历史记录为空 → 上下文归零

为什么不是"删/挪走文件"：那样 resume 会直接失败
（thread/resume failed: no rollout found for thread id ...），cc-connect 并不会
自动换新会话（它的兜底只在 agent.StartSession 报错时触发，而 codex CLI 模式下
进程能正常启动，错误发生在这一轮对话里）。截断则不会触发任何错误。

实测证据：截断后的 thread 用 `codex exec resume` 跑通，exit 0；模型回答"无历史"；
rollout 随后正常续写，ordinal 从 0 连续递增。

归档而非删除：备份按天存放，脚本每轮自动删掉三天前的归档（KEEP_DAYS）。
想还原某次清空前的完整上下文，用日志里给出的 cp 命令即可。

被占用不再干等到下个整点（2026-09-23 修）：如果那一刻正好有 agent 在用这个
CODEX_HOME（清空会打断进行中的一轮），就每 RETRY_SECS 秒重试一次，直到清空
成功；最多等 DEADLINE_MINS 分钟，超了才放弃本轮、交给下个整点。
（cron 的 timeout_mins 必须大于 DEADLINE_MINS，否则会被提前杀掉。）

用法：
  python3 rotate-codex-session.py             # 执行（默认只处理 codex 项目）
  python3 rotate-codex-session.py codex3      # 只处理指定项目
  python3 rotate-codex-session.py codex3 codex4 ...
  python3 rotate-codex-session.py --dry-run   # 只打印将要做什么，不动文件
"""
import datetime
import glob
import hashlib
import json
import os
import shutil
import sys
import time
import tomllib

CONFIG       = "/workspace/cc-connect/config.toml"
DATA_DIR     = "/workspace/cc-connect/data"
ARCHIVE_ROOT = "/workspace/cc-connect/session-archive"
LOG          = "/workspace/cc-connect/rotate-session.log"
KEEP_DAYS    = 3      # 备份保留「三天内」：当天 + 前 2 天，更早的归档目录每轮自动删除
DEFAULT_PROJECT = "codex"   # 不带参数时处理哪个项目（保持既有 cron 作业的行为不变）
RETRY_SECS   = 30     # 被占用时每隔多少秒重试一次
DEADLINE_MINS = 25    # 重试总时长上限（cron 的 timeout_mins 要大于它）

DRY = "--dry-run" in sys.argv
# 位置参数里除了 --dry-run 之外的都是项目名；没给就退回默认项目
PROJECTS = [a for a in sys.argv[1:] if not a.startswith("-")] or [DEFAULT_PROJECT]


def log(msg: str) -> None:
    line = f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def codex_project(name: str) -> dict:
    """从 config.toml 里读某个 codex 项目块（不写死路径）"""
    with open(CONFIG, "rb") as fh:
        cfg = tomllib.load(fh)
    for proj in cfg.get("projects", []):
        if proj.get("name") == name:
            return proj
    return {}


def codex_home(proj: dict) -> str:
    return ((proj.get("agent") or {}).get("options") or {}).get("codex_home") or ""


def effective_work_dir(proj: dict, name: str) -> str:
    """复刻 cc-connect: 配置里的 work_dir，被 /cd 写下的 work_dir_override 覆盖"""
    wd = ((proj.get("agent") or {}).get("options") or {}).get("work_dir") or ""
    state = os.path.join(DATA_DIR, "projects", f"{name}.state.json")
    try:
        with open(state, encoding="utf-8") as fh:
            override = (json.load(fh) or {}).get("work_dir_override") or ""
    except (OSError, ValueError):
        override = ""
    if override and os.path.isdir(override):
        return os.path.abspath(override)
    return os.path.abspath(wd) if wd else ""


def state_files(proj: dict, name: str) -> list:
    """定位该项目的会话状态文件。复刻 cmd/cc-connect/main.go:1446 sessionStorePath：
    <data_dir>/sessions/<项目名>_<sha256(绝对work_dir)前8位>.json；找不到就回退到全部候选。"""
    wd = effective_work_dir(proj, name)
    cands = []
    if wd:
        fname = f"{name}_{hashlib.sha256(wd.encode()).hexdigest()[:8]}.json"
        cands = [os.path.join(DATA_DIR, "sessions", fname), os.path.join(DATA_DIR, fname)]
    hits = [p for p in cands if os.path.exists(p)]
    if hits:
        return hits
    log(f"[{name}] 按 work_dir({wd or '未设置'}) 算出的状态文件不存在，"
        f"回退扫描全部 {name}_*.json")
    return sorted(glob.glob(os.path.join(DATA_DIR, "sessions", f"{name}_*.json")))


def find_rollout(home: str, agent_sid: str) -> str:
    """按 cc-connect 的查找规则定位 thread 文件：<codex_home>/sessions/*/*/*/rollout-*<id>.jsonl"""
    pat = os.path.join(home, "sessions", "*", "*", "*", f"rollout-*{agent_sid}.jsonl")
    hits = sorted(glob.glob(pat))
    return hits[-1] if hits else ""


def codex_busy(home: str):
    """有 codex 进程正用着这个 CODEX_HOME 时返回 pid，否则 None（避免打断进行中的一轮）"""
    for ent in os.listdir("/proc"):
        if not ent.isdigit():
            continue
        try:
            with open(f"/proc/{ent}/cmdline", "rb") as fh:
                cmd = fh.read()
            if b"codex" not in cmd:
                continue
            with open(f"/proc/{ent}/environ", "rb") as fh:
                env = fh.read()
        except OSError:
            continue
        for item in env.split(b"\0"):
            if item.startswith(b"CODEX_HOME=") and item.split(b"=", 1)[1].decode() == home:
                return ent
    return None


def backup_name(basename: str) -> str:
    """给备份文件名打上时间戳，避免多次清空互相覆盖（同一 thread 每小时都会备份一次）"""
    stem, ext = os.path.splitext(basename)
    ts = datetime.datetime.now().strftime("%H%M%S")
    return f"{stem}.{ts}{ext}"


def truncate_to_meta(src: str, dst: str) -> None:
    """整份备份到 dst，再把 src 原子地截断到只剩第 1 行（须为 session_meta）"""
    with open(src, "rb") as fh:
        first = fh.readline()
        rest = fh.read()
    if not rest.strip():
        raise ValueError("文件本来就只有一行，无需截断")
    try:
        meta = json.loads(first)
    except ValueError as exc:
        raise ValueError(f"第 1 行不是合法 JSON：{exc}") from exc
    if meta.get("type") != "session_meta":
        raise ValueError(f"第 1 行不是 session_meta（是 {meta.get('type')!r}），拒绝截断")

    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)
    if os.path.getsize(dst) != os.path.getsize(src):
        raise OSError("备份大小与源文件不一致，放弃截断")

    tmp = src + ".truncating"
    with open(tmp, "wb") as fh:
        fh.write(first)
    os.replace(tmp, src)          # 原子替换：读方永远看不到半截文件
    if os.path.getsize(src) != len(first):
        raise OSError("截断后大小异常")


def prune_archive() -> None:
    """清掉过期归档：只保留「三天内」——当天 + 前 2 天（每轮都会跑，与是否清空无关）"""
    cutoff = datetime.date.today() - datetime.timedelta(days=KEEP_DAYS - 1)
    for entry in glob.glob(os.path.join(ARCHIVE_ROOT, "*")):
        try:
            day = datetime.date.fromisoformat(os.path.basename(entry))
        except ValueError:
            continue
        if day < cutoff:
            if DRY:
                log(f"DRY-RUN 会删除过期归档 {entry}")
            else:
                shutil.rmtree(entry, ignore_errors=True)
                log(f"已删除过期归档 {entry}")


def rotate_one(name: str) -> tuple:
    """清空单个项目的活跃会话上下文。

    返回 (退出码, 是否因"进程占用"被跳过)：
      (0, False) 成功（含"本轮没什么可做"）
      (1, False) 失败
      (0, True)  该 home 正被执行中的 agent 占用，这次没清 → 调用方决定是否重试
    """
    proj = codex_project(name)
    home = codex_home(proj)
    if not home:
        log(f"[{name}] ERROR 配置里找不到该项目的 codex_home，放弃本轮")
        return 1, False
    if not os.path.isdir(home):
        log(f"[{name}] ERROR codex_home 不存在：{home}")
        return 1, False

    busy = codex_busy(home)
    if busy:
        log(f"[{name}] codex 进程 pid={busy} 正在使用 {home}，这次跳过")
        return 0, True

    dst_dir = os.path.join(ARCHIVE_ROOT, datetime.date.today().isoformat())
    done = 0

    for state_path in state_files(proj, name):
        try:
            with open(state_path, encoding="utf-8") as fh:
                state = json.load(fh)
        except (OSError, ValueError) as exc:
            log(f"[{name}] WARN 读不了 {state_path}: {exc}")
            continue

        sessions = state.get("sessions") or {}
        for skey, sid in (state.get("active_session") or {}).items():
            agent_sid = (sessions.get(sid) or {}).get("agent_session_id") or ""
            if not agent_sid:
                log(f"[{name}] 跳过 {skey}：活跃会话 {sid} 没有 agent_session_id（本来就是新会话）")
                continue
            src = find_rollout(home, agent_sid)
            if not src:
                log(f"[{name}] 跳过 {skey}：找不到 thread 文件 {agent_sid}")
                continue
            dst = os.path.join(dst_dir, backup_name(os.path.basename(src)))
            if DRY:
                n = sum(1 for _ in open(src, "rb"))
                log(f"[{name}] DRY-RUN 会备份并截断 {skey} 的 thread {agent_sid}（{n} 行）-> 备份 {dst}")
            else:
                try:
                    truncate_to_meta(src, dst)
                except (OSError, ValueError) as exc:
                    log(f"[{name}] WARN 处理 {src} 失败：{exc}")
                    continue
                log(f"[{name}] 已清空 {skey} 的上下文：thread {agent_sid} 截断为仅 session_meta，"
                    f"整份备份 -> {dst}（回滚：cp {dst} {src}）")
            done += 1

    if done == 0:
        log(f"[{name}] 本轮没有需要清空的活跃会话")
    return 0, False


def rotate_with_retry(name: str) -> int:
    """被 agent 占用导致的跳过，不等到下个整点：每 RETRY_SECS 秒重试一次，
    直到成功或超过 DEADLINE_MINS 分钟（超过就放弃本轮，交给下个整点）。"""
    start = time.time()
    attempt = 0
    while True:
        attempt += 1
        rc, busy = rotate_one(name)
        if not busy:
            if attempt > 1:
                log(f"[{name}] 第 {attempt} 次尝试成功，本轮结束")
            return rc
        if DRY:
            return 0
        waited = time.time() - start
        if waited + RETRY_SECS > DEADLINE_MINS * 60:
            log(f"[{name}] 已等 {waited / 60:.1f} 分钟仍被占用，放弃本轮（下个整点再来）")
            return 0
        log(f"[{name}] 第 {attempt} 次仍被占用，{RETRY_SECS} 秒后重试（已等 {waited / 60:.1f} 分钟）")
        time.sleep(RETRY_SECS)


def main() -> int:
    # 保留期清理放在最前面：无论本轮是否真的清空会话，过期备份都要删掉
    prune_archive()

    # 逐个项目处理：一个项目失败不拖累其他项目，但整体退出码仍反映失败
    rc = 0
    for name in PROJECTS:
        rc |= rotate_with_retry(name)
    return rc


if __name__ == "__main__":
    sys.exit(main())
