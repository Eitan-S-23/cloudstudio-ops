#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""seed-cron-jobs.py —— 把定时作业种子(jobs-seed.json)预置进本容器 cc-connect 的
data/crons/jobs.json,补齐缺失的作业。

为什么用"预置文件"而不是聊天里的 /cron 命令:
    /cron 的聊天子命令(add / addexec / …)设置不了 silent 字段 —— cc-connect 源码里
    silent 只存在于 jobs.json 的作业记录上,而 MonkeyCode 的 10 条每小时轮换作业是
    silent=true + mute=true(不打扰、不投递)。要一比一,只能让作业以 JSON 形式预置
    进去;先例:腾讯容器现在那条 codex 轮换作业(377cba56)当年就是这么整条带过来的
    (与 MonkeyCode 快照逐字段相同)。

合并语义(幂等,对齐 + 补齐):
    · 按 id 对齐:种子里凡目标里已有的条目,只把 SYNC_FIELDS(目前仅 description,
      即 /cron 卡面文案——按目标容器改名用)更新成种子里的值;其余字段一字不动
      (运行态 enabled/last_run、部署后对齐过的 session_key 都保留原样);
    · 补齐缺失:种子里有、目标里没有的条目整条新增;
    · 目标里其它作业(后来自己加的)原样保留;
    · 写盘前备份 jobs.json.pre-seed,写入用"临时文件 + 原子改名",写后逐条回验。

执行顺序(重要):
    cc-connect 运行时,每次作业执行完都会把内存里的作业表整份写回 jobs.json ——
    单独 seed 会在下一次作业运行后被覆盖。正确做法是把写盘和立刻重启连成一条:
        python3 seed-cron-jobs.py --apply && pkill -f ^/workspace/cc-connect/cc-connect
    (watchdog 10 秒内自动拉起;新进程启动时加载的就是 seed 之后的文件。)

用法(容器内,默认路径已对好):
    python3 /workspace/cc-connect/seed-cron-jobs.py           # 巡检:只报告,不写盘
    python3 /workspace/cc-connect/seed-cron-jobs.py --apply && pkill -f ^/workspace/cc-connect/cc-connect
    python3 /workspace/cc-connect/seed-cron-jobs.py --jobs X.json --target Y.json   # 换路径(验证用)
"""

import argparse
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys

# 输出流定死 UTF-8:容器 LANG 未必是 UTF-8,否则打印 ✅ 会在"已经写盘之后"抛异常,
# 脚本以非零码退出、和真的失败分不开。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass

DEFAULT_JOBS = "/workspace/cc-connect/jobs-seed.json"
DEFAULT_TARGET = "/workspace/cc-connect/data/crons/jobs.json"
PROC_MATCH = "^/workspace/cc-connect/cc-connect"
ID_RE = re.compile(r"^[0-9a-f]{8}$")
# 已有作业里允许种子对齐的字段:只限卡面文案。想加字段前先想清楚——运行态字段
# (enabled/last_run)与被部署后对齐过的 session_key 一旦被种子回写,当地改过的
# 状态就没了;这是刻意留的最小口子,不是通用覆盖。
SYNC_FIELDS = ("description",)


def parse_args():
    p = argparse.ArgumentParser(
        description="把作业种子合并进 cc-connect 的 jobs.json(默认只巡检,不写盘)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--jobs", default=DEFAULT_JOBS, help=f"作业种子文件(默认 {DEFAULT_JOBS})")
    p.add_argument("--target", default=DEFAULT_TARGET, help=f"目标作业表(默认 {DEFAULT_TARGET})")
    p.add_argument("--apply", action="store_true", help="真正写盘(默认只巡检)")
    return p.parse_args()


def load_list(path, required, what):
    """读一个 JSON 数组;空文件按 [] 处理;坏 JSON / 顶层不是数组都停下来让人先修"""
    if not path.is_file():
        if required:
            raise SystemExit(f"❌ 找不到{what}: {path}(确认它已被复制进 /workspace/cc-connect/)")
        return None
    text = path.read_text(encoding="utf-8")
    if not text.strip():
        print(f"  ℹ️ {what}是空文件,按空作业表处理: {path}")
        return []
    try:
        doc = json.loads(text)
    except ValueError as error:
        raise SystemExit(f"❌ {path} 不是合法 JSON,先修好再跑(本脚本不猜):\n   {error}")
    if not isinstance(doc, list):
        raise SystemExit(f"❌ {path} 的顶层不是 JSON 数组(作业表应为 [ … ])")
    return doc


def validate_seed(jobs):
    """种子必须条条可用:预置进去后要到整点触发才会暴露问题,那时早已离开部署现场。
    与 add-codex-bots.py 同一原则:宁可现在停手,不要埋雷。"""
    seen = set()
    for i, job in enumerate(jobs, 1):
        where = f"种子第 {i} 条"
        if not isinstance(job, dict):
            raise SystemExit(f"❌ {where}不是对象")
        jid = job.get("id")
        if not isinstance(jid, str) or not ID_RE.match(jid):
            raise SystemExit(f"❌ {where}的 id 不是 8 位十六进制: {jid!r}")
        if jid in seen:
            raise SystemExit(f"❌ 种子里 id {jid} 出现了两次")
        seen.add(jid)
        for key in ("project", "session_key", "cron_expr", "description"):
            if not isinstance(job.get(key), str) or not job[key]:
                raise SystemExit(f"❌ {where}({jid})缺 {key} 或为空")
        if not job["session_key"].startswith("feishu:"):
            raise SystemExit(f"❌ {where}({jid})的 session_key 不是 feishu: 开头")
        if not job.get("exec") and not job.get("prompt"):
            raise SystemExit(f"❌ {where}({jid})既没有 exec 也没有 prompt,触发了不知道干什么")
        if len(job["cron_expr"].split()) != 5:
            raise SystemExit(f"❌ {where}({jid})的 cron_expr 不是 5 段: {job['cron_expr']!r}")
        if not isinstance(job.get("enabled"), bool):
            raise SystemExit(f"❌ {where}({jid})缺 enabled(布尔值)")
        for opt in ("silent", "mute"):
            if opt in job and not isinstance(job[opt], bool):
                raise SystemExit(f"❌ {where}({jid})的 {opt} 不是布尔值")
    return seen


def cc_running():
    """cc-connect 是否在跑。只用它决定提示语,判错不影响正确性"""
    try:
        return subprocess.run(["pgrep", "-f", PROC_MATCH],
                              capture_output=True, text=True).returncode == 0
    except (FileNotFoundError, OSError):
        return False


def main():
    args = parse_args()
    seed_path = pathlib.Path(args.jobs)
    target_path = pathlib.Path(args.target)

    seed = load_list(seed_path, required=True, what="作业种子")
    validate_seed(seed)
    target = load_list(target_path, required=False, what="目标作业表")
    if target is None:
        print(f"  ℹ️ 目标 jobs.json 还不存在,将新建: {target_path}")
        target = []

    target_ids = [j.get("id") for j in target
                  if isinstance(j, dict) and isinstance(j.get("id"), str)]
    if len(target_ids) != len(set(target_ids)):
        raise SystemExit("❌ 目标 jobs.json 里有重复 id,先修好(本脚本不猜该留哪条)")
    have = set(target_ids)
    seed_ids = {j["id"] for j in seed}
    missing = [j for j in seed if j["id"] not in have]
    foreign = [jid for jid in target_ids if jid not in seed_ids]

    by_id = {j["id"]: j for j in target
             if isinstance(j, dict) and isinstance(j.get("id"), str)}
    updates = []          # [(种子条目, 字段, 旧值)] —— 只限 SYNC_FIELDS
    for sj in seed:
        tj = by_id.get(sj["id"])
        if tj is None:
            continue
        for field in SYNC_FIELDS:
            if field in sj and tj.get(field) != sj[field]:
                updates.append((sj, field, tj.get(field)))

    print(f"种子: {seed_path}({len(seed)} 条)")
    print(f"目标: {target_path}(现有 {len(target)} 条)")
    print()
    if missing:
        print(f"将新增 {len(missing)} 条:")
        for j in missing:
            state = "启用" if j.get("enabled") else "停用"
            print(f"  + [{j['id']}] {j['project']:<8} {j['cron_expr']:<12} {state}  "
                  f"{j['description'][:30]}")
    else:
        print("种子里没有新条目 —— 目标已是种子超集")
    skipped = len(seed) - len(missing)
    if skipped:
        print(f"已存在 {skipped} 条(其余字段一字不动)")
    if updates:
        print(f"将对齐 {len(updates)} 处已有作业的文案(仅 {', '.join(SYNC_FIELDS)}):")
        for sj, field, old in updates:
            print(f"  ~ [{sj['id']}] {sj['project']:<8} {field}: {old}  →  {sj[field]}")
    if foreign:
        print(f"目标里另有 {len(foreign)} 条不属于本种子的作业,保留不动: {', '.join(foreign)}")

    if not missing and not updates:
        print("\n✅ 无需改动。")
        return 0
    if not args.apply:
        print("\n巡检结束:未写盘。确认无误后执行下面这条(写盘与重启必须连成一条):")
        print("  python3 /workspace/cc-connect/seed-cron-jobs.py --apply"
              " && pkill -f ^/workspace/cc-connect/cc-connect")
        return 0

    target_path.parent.mkdir(parents=True, exist_ok=True)
    if target_path.is_file():
        backup = target_path.with_name(target_path.name + ".pre-seed")
        shutil.copyfile(target_path, backup)
    sync_map = {(sj["id"], field): sj[field] for sj, field, _ in updates}
    merged = []
    for j in target:
        jid = j.get("id") if isinstance(j, dict) else None
        patch = {field: sync_map[(jid, field)] for field in SYNC_FIELDS
                 if (jid, field) in sync_map}
        merged.append({**j, **patch} if patch else j)
    merged += missing
    tmp = target_path.with_name(target_path.name + f".tmp-{os.getpid()}")
    try:
        tmp.write_text(json.dumps(merged, ensure_ascii=False, indent=2) + "\n",
                       encoding="utf-8", newline="\n")
        os.replace(tmp, target_path)
    except OSError as error:
        raise SystemExit(f"❌ 写入失败: {error}")

    # 写后回验:重读刚写的文件,和预期合并结果必须逐字段一致,不一致显式报错
    try:
        got = json.loads(target_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise SystemExit(f"❌ 回验读不回刚写的文件: {error}")
    if got != merged:
        raise SystemExit(f"❌ 回验失败:{target_path} 与预期合并结果不一致,"
                         f"请从 {target_path.with_name(target_path.name + '.pre-seed')} 恢复后重来")
    print(f"\n✅ 已写入 {target_path}:新增 {len(missing)} 条,对齐文案 {len(updates)} 处,"
          f"该文件现有 {len(merged)} 条")
    print("   回验通过(重读文件与预期逐字段一致)")
    print(f"   备份: {target_path.with_name(target_path.name + '.pre-seed')}")

    if cc_running():
        print()
        print("  ⚠️ cc-connect 仍在运行 —— 必须立刻重启,否则下一次作业运行会把内存里的旧")
        print("     作业表整份写回、覆盖这次预置。若你这次没带 pkill,现在补上:")
        print("     pkill -f ^/workspace/cc-connect/cc-connect")
    else:
        print("  ℹ️ cc-connect 当前未在运行,下次启动时生效")
    print()
    print("  重启约 30 秒后自查:pgrep -af cc-connect;tail -20 /workspace/cc-connect/cc.log")
    return 0


if __name__ == "__main__":
    sys.exit(main())
