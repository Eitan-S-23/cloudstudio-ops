#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""set-cron-session.py —— 把 jobs.json 里各台定时作业的 session_key 同步为
本容器的实际会话键(取自 config.toml 各台的 [projects.heartbeat].session_key)。

为什么需要这一步(与私有仓库 README「在容器里部署」第 3 步同源,这里是多台版):
    /cron 裸命令渲染的是"按会话过滤"的作业卡片 —— cc-connect 源码 renderCronCard
    走 ListBySessionKey(当前会话键);而 /cron list 按 project 过滤,不受影响。
    jobs.json 从原机快照搬来时,键还指向原机会话、本容器不存在 → 卡片恒为空,
    看着像"没配置"。作业**执行**按 project 找引擎(runJob),与 session_key 无关 ——
    exec 作业照常跑,本脚本只影响卡片/列表的可见性。
    先例:当年单台 codex 是用一行 python -c 手工替换的(README 有留档);
    本脚本把它做成多台自动版:逐台对齐、备份、回验,一次搞定。

会话键来源:
    config.toml [projects.heartbeat].session_key —— 由 set-heartbeat.py 写入;
    心跳能发出去就证明键是对的,比再扫一遍 data/sessions 更权威。
    没有心跳键(或键不是 feishu: 开头)的 project 会被列进"跳过":
    先 python3 set-heartbeat.py <project>(或检查它的心跳段)。

执行顺序(重要,与 seed-cron-jobs.py 同一纪律):
    cc-connect 运行时,每次作业执行完都会把内存里的作业表整份写回 jobs.json ——
    单独改文件会在下一次作业运行后被覆盖。正确做法是把写盘和立刻重启连成一条:
        python3 set-cron-session.py --apply && pkill -f ^/workspace/cc-connect/cc-connect
    (watchdog 10 秒内自动拉起;新进程启动时加载的就是改过的文件。)
    另:避开整点 :00~:02 执行 —— 那几秒里轮换作业可能刚跑完、引擎正在回写。

用法(容器内,默认路径已对好):
    python3 /workspace/cc-connect/set-cron-session.py           # 巡检:只报告,不写盘
    python3 /workspace/cc-connect/set-cron-session.py --apply && pkill -f ^/workspace/cc-connect/cc-connect
    python3 /workspace/cc-connect/set-cron-session.py --config X.toml --target Y.json   # 换路径(验证用)
"""

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import sys

# 输出流定死 UTF-8:容器 LANG 未必是 UTF-8,否则打印 ✅ 会在"已经写盘之后"抛异常,
# 脚本以非零码退出、和真的失败分不开。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass

DEFAULT_CONFIG = "/workspace/cc-connect/config.toml"
DEFAULT_TARGET = "/workspace/cc-connect/data/crons/jobs.json"
PROC_MATCH = "^/workspace/cc-connect/cc-connect"


def parse_args():
    p = argparse.ArgumentParser(
        description="把各台定时作业的 session_key 同步为本容器的实际会话(默认只巡检,不写盘)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--config", default=DEFAULT_CONFIG, help=f"配置文件路径(默认 {DEFAULT_CONFIG})")
    p.add_argument("--target", default=DEFAULT_TARGET, help=f"目标作业表(默认 {DEFAULT_TARGET})")
    p.add_argument("--apply", action="store_true", help="真正写盘(默认只巡检)")
    return p.parse_args()


def toml_load(text):
    try:
        import tomllib
    except ModuleNotFoundError:
        raise SystemExit("❌ 读 config.toml 需要 python3.11+ 的 tomllib,当前 python 没有")
    try:
        return tomllib.loads(text)
    except Exception as error:  # noqa: BLE001 —— 解析失败原因多样,统一报给用户
        raise SystemExit(f"❌ config 不是合法 TOML,先修好再跑本脚本:\n   {error}")


def heartbeat_keys(doc):
    """{project: session_key}:只收"配了心跳、且键是 feishu: 开头"的台。

    没配心跳 / 键不成形的台不进表 —— 调用方把它们的作业列成"跳过"并给出台名,
    提醒先去 set-heartbeat.py 配好,而不是拿半个键去写。
    """
    out = {}
    for proj in doc.get("projects", []) or []:
        name = (proj.get("name") or "").strip()
        key = ((proj.get("heartbeat") or {}).get("session_key") or "").strip()
        if name and key.startswith("feishu:"):
            out[name] = key
    return out


def mask(key):
    """显示用缩略:feishu:oc_<28hex>:ou_<30hex> → 62bc44/672c(oc 前 6 位 / ou 前 4 位)。
    屏幕与聊天里都不给全键;要看全键直接看文件。"""
    parts = str(key).split(":")
    if len(parts) < 3:
        return str(key)[:12]
    return f"{parts[1][3:9]}/{parts[2][3:7]}"


def load_jobs(path):
    """读作业表:必须是 JSON 数组、条条是对象 —— 坏输入停下来让人先修,本脚本不猜"""
    if not path.is_file():
        raise SystemExit(f"❌ 找不到目标作业表: {path}(确认容器里 cc-connect 已部署过)")
    text = path.read_text(encoding="utf-8")
    try:
        doc = json.loads(text)
    except ValueError as error:
        raise SystemExit(f"❌ {path} 不是合法 JSON,先修好再跑(本脚本不猜):\n   {error}")
    if not isinstance(doc, list):
        raise SystemExit(f"❌ {path} 的顶层不是 JSON 数组(作业表应为 [ … ])")
    for i, job in enumerate(doc, 1):
        if not isinstance(job, dict):
            raise SystemExit(f"❌ 作业表第 {i} 条不是对象,先修好(本脚本不猜)")
    return doc


def cc_running():
    """cc-connect 是否在跑。只用它决定提示语,判错不影响正确性"""
    try:
        return subprocess.run(["pgrep", "-f", PROC_MATCH],
                              capture_output=True, text=True).returncode == 0
    except (FileNotFoundError, OSError):
        return False


def main():
    args = parse_args()
    cfg = pathlib.Path(args.config)
    target = pathlib.Path(args.target)
    if not cfg.is_file():
        raise SystemExit(f"❌ 找不到配置文件: {cfg}")
    keys = heartbeat_keys(toml_load(cfg.read_text(encoding="utf-8")))
    if not keys:
        raise SystemExit("❌ config 里没有任何台配了可用的 [projects.heartbeat].session_key;"
                         "先跑 set-heartbeat.py 再回来")
    jobs = load_jobs(target)

    # 计划:哪几条作业要换成哪个键;顺带统计"已一致"与"跳过"
    changed = []           # [(下标, 新键), …]
    per_proj = {}          # 台名 -> {"n": 条数, "old": 首个旧键, "new": 新键}(插入序 = 台出现序)
    same = 0
    skipped = {}           # 台名(或占位) -> 条数
    for i, job in enumerate(jobs):
        name = job.get("project") or ""
        new = keys.get(name)
        cur = job.get("session_key")
        if not new:
            where = name or "(缺 project)"
            skipped[where] = skipped.get(where, 0) + 1
            continue
        if cur == new:
            same += 1
            continue
        changed.append((i, new))
        entry = per_proj.setdefault(name, {"n": 0, "old": cur, "new": new})
        entry["n"] += 1

    print(f"作业表 {target}({len(jobs)} 条)· 心跳键来自 {cfg}({len(keys)} 台)")
    for name, entry in per_proj.items():
        print(f"  ▸ {name:<8} x{entry['n']}  {mask(entry['old'])} → {mask(entry['new'])}")
    skip_note = ""
    if skipped:
        skip_note = f" · 无可用心跳键跳过 {sum(skipped.values())} 条(" + \
                    ", ".join(f"{k}:{v}" for k, v in skipped.items()) + ")"
    print(f"合计: 待更新 {len(changed)} 条 · 已一致 {same} 条{skip_note}")

    if not changed:
        print("\n✅ 无需改动(全部作业的会话键已与 config 里的心跳键一致)。")
        return 0
    if not args.apply:
        print("\n未写盘。确认无误后执行下面这条(写盘与重启必须连成一条,原因见文件头):")
        print("  python3 /workspace/cc-connect/set-cron-session.py --apply"
              " && pkill -f ^/workspace/cc-connect/cc-connect")
        return 0

    # 先备份(.pre-skey 与 README 里当年单台手工版的备份同名),再原子写
    backup = target.with_name(target.name + ".pre-skey")
    shutil.copyfile(target, backup)
    new_jobs = [dict(j) for j in jobs]
    for i, key in changed:
        new_jobs[i]["session_key"] = key
    tmp = target.with_name(target.name + f".tmp-{os.getpid()}")
    try:
        tmp.write_text(json.dumps(new_jobs, ensure_ascii=False, indent=2) + "\n",
                       encoding="utf-8", newline="\n")
        os.replace(tmp, target)
    except OSError as error:
        raise SystemExit(f"❌ 写入失败: {error}")

    # 写后回验:条数不变、该换的都换了、其余字段一字未动
    reloaded = json.loads(target.read_text(encoding="utf-8"))
    if len(reloaded) != len(jobs):
        raise SystemExit("❌ 回验失败:写回后作业条数不对")
    for i, key in changed:
        if reloaded[i].get("session_key") != key:
            raise SystemExit(f"❌ 回验失败:第 {i + 1} 条 session_key 期望 {key!r},"
                             f"实得 {reloaded[i].get('session_key')!r}")
        rest_old = {k: v for k, v in jobs[i].items() if k != "session_key"}
        rest_new = {k: v for k, v in reloaded[i].items() if k != "session_key"}
        if rest_old != rest_new:
            raise SystemExit(f"❌ 回验失败:第 {i + 1} 条除 session_key 外还有字段被改动")

    print(f"\n✅ 已更新 {len(changed)} 条作业的会话键({len(per_proj)} 台),回验通过")
    print(f"   备份: {backup}")

    if cc_running():
        print()
        print("  ⚠️ cc-connect 仍在运行 —— 必须立刻重启,否则下一次作业运行会把内存里的旧")
        print("     作业表整份写回、覆盖这次修改。若你这次没带 pkill,现在补上:")
        print("     pkill -f ^/workspace/cc-connect/cc-connect")
    else:
        print("  ℹ️ cc-connect 当前未在运行,下次启动时生效")
    print()
    print("  重启约 30 秒后自查:python3 set-cron-session.py(应显示「无需改动」)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
