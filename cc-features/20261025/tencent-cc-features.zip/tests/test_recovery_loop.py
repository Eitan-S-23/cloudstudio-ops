import datetime
import hashlib
import importlib.util
import json
import os
import subprocess
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

BASE = Path(__file__).resolve().parent
SCRIPTS = Path(os.environ.get("RECOVERY_SCRIPTS_DIR", str(BASE.parent)))
NOW = datetime.datetime.now(datetime.UTC)
PROMPT = "heartbeat probe"


def module(name):
    spec = importlib.util.spec_from_file_location(name.replace("-", "_"), SCRIPTS / (name + ".py"))
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def entry(role, age, content="normal response"):
    return {"role": role, "timestamp": (NOW - datetime.timedelta(seconds=age)).isoformat(),
            "content": content}


class RecoveryLoopTests(unittest.TestCase):
    def setUp(self):
        temp_root = Path(os.environ.get("RECOVERY_TEST_TMPDIR", str(BASE.parent / ".cache")))
        temp_root.mkdir(parents=True, exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix="case-", dir=temp_root)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.data = self.root / "data"
        (self.data / "crons").mkdir(parents=True)
        (self.data / "sessions").mkdir()
        self.rec = module("codex-recovery-watch")
        self.up = module("codex-upstream-watch")
        self.restore = module("codex-restore-heartbeat")
        self.jobs = [
            {"id": "stop", "project": "codex1", "session_key": "test-session", "enabled": True,
             "exec": "python codex-recovery-watch.py"},
            {"id": "restore", "project": "codex1", "enabled": False,
             "exec": "python codex-restore-heartbeat.py"},
            {"id": "up", "project": "codex1", "enabled": False,
             "exec": "python codex-upstream-watch.py"},
        ]
        self.write_jobs()
        self.paused = {n: False for n in self.rec.PROJECTS}
        self.api_calls = []
        self.cli_calls = []
        self.fail_pause = set()
        self.fail_resume = set()
        self.fail_status = set()
        self.fail_edit = set()
        self.unconfirmed_edit = set()
        self.cfg = {"projects": []}
        for n in ["codex"] + self.rec.PROJECTS:
            home = self.root / (n + "-home")
            home.mkdir()
            self.cfg["projects"].append({"name": n, "heartbeat": {"prompt": PROMPT},
                                         "agent": {"options": {"work_dir": str(self.root),
                                                                "codex_home": str(home)}}})
        self.rot = types.SimpleNamespace(codex_home=lambda p: p["agent"]["options"]["codex_home"],
                                         codex_busy=Mock(return_value=None),
                                         state_files=Mock(return_value=[]),
                                         rotate_one=Mock(return_value=(0, False)))
        for m in (self.rec, self.up, self.restore):
            m.DATA_DIR = str(self.data)
            m.CONFIG = str(self.root / "config.toml")
            m.LOG = str(self.root / "test.log")
            m.DRY = False
            m.STATUS_ONLY = False
            self.start(patch.object(m, "log", Mock()))
            self.start(patch.object(m, "notify", Mock()))
        self.start(patch.object(self.rec, "load_config", return_value=self.cfg))
        self.start(patch.object(self.restore, "load_config", return_value=self.cfg))
        self.start(patch.object(self.up, "load_watch", return_value=self.rec))
        self.start(patch.object(self.restore, "load_watch", return_value=self.rec))
        self.start(patch.object(self.restore, "load_rotate", return_value=self.rot))
        self.start(patch.object(self.restore.time, "sleep", return_value=None))
        self.start(patch.object(self.rec, "api", side_effect=self.api))
        self.start(patch.object(self.restore, "api", side_effect=self.api))
        self.start(patch.object(subprocess, "run", side_effect=self.cli))
        self.up.CC_LOG = str(self.root / "cc.log")

    def start(self, p):
        result = p.start()
        self.addCleanup(p.stop)
        return result

    def write_jobs(self):
        (self.data / "crons/jobs.json").write_text(json.dumps(self.jobs), encoding="utf-8")

    def job(self, name):
        return next(j for j in self.jobs if j["id"] == name)

    def enable(self, name, enabled):
        self.job(name)["enabled"] = enabled
        self.write_jobs()

    def history(self, name, entries):
        suffix = hashlib.sha256(str(self.root).encode()).hexdigest()[:8]
        p = self.data / "sessions" / (name + "_" + suffix + ".json")
        p.write_text(json.dumps({"active_session": {"chat": "session"},
                                 "sessions": {"session": {"history": entries}}}), encoding="utf-8")

    def api(self, cfg, method, path):
        self.api_calls.append((method, path))
        name = path.split("/")[2]
        action = path.rsplit("/", 1)[1]
        if action == "status":
            if name in self.fail_status:
                raise OSError("status unavailable")
            return 200, json.dumps({"data": {"paused": self.paused[name]}})
        if action == "pause":
            if name in self.fail_pause:
                raise OSError("pause unavailable")
            self.paused[name] = True
        elif action == "resume":
            if name in self.fail_resume:
                raise OSError("resume unavailable")
            self.paused[name] = False
        else:
            raise AssertionError(path)
        return 200, "{}"

    def cli(self, args, **kwargs):
        self.assertEqual(args[1:3], ["cron", "edit"])
        name = args[3]
        enabled = args[5] == "true"
        self.cli_calls.append((name, enabled))
        self.assertEqual(kwargs["cwd"], str(self.root))
        if (name, enabled) in self.fail_edit:
            return subprocess.CompletedProcess(args, 1, b"", b"failed")
        if (name, enabled) not in self.unconfirmed_edit:
            self.enable(name, enabled)
        return subprocess.CompletedProcess(args, 0, b"ok", b"")

    def healthy(self):
        self.history("codex1", [entry("user", 30, PROMPT), entry("assistant", 20)])

    def stopped(self):
        self.paused = dict.fromkeys(self.rec.PROJECTS, True)

    def monitoring(self, age=600):
        self.rec.save_cycle({"phase": "monitoring", "monitor_since": (
            NOW - datetime.timedelta(seconds=age)).isoformat()})
        self.enable("stop", False)
        self.enable("up", True)
        self.stopped()

    def test_normal_stop_rearms_upstream_and_self_disables(self):
        self.healthy()
        self.assertEqual(self.rec.run(), 0)
        self.assertTrue(all(self.paused.values()))
        self.assertTrue(self.job("up")["enabled"])
        self.assertFalse(self.job("stop")["enabled"])
        self.assertEqual(self.rec.load_cycle()["phase"], "monitoring")
        self.assertFalse(any("/codex/" in path for _, path in self.api_calls))

    def test_already_paused_legacy_still_completes_handoff(self):
        self.stopped()
        self.healthy()
        self.assertEqual(self.rec.run(), 0)
        self.assertTrue(self.job("up")["enabled"])
        self.assertFalse(any(method == "POST" for method, _ in self.api_calls))

    def test_pause_failure_retries_after_reply_window_expires(self):
        self.healthy()
        self.fail_pause.add("codex4")
        self.assertEqual(self.rec.run(), 1)
        self.assertEqual(self.rec.load_cycle()["phase"], "stopping")
        self.assertTrue(self.job("stop")["enabled"])
        self.assertFalse(self.job("up")["enabled"])
        self.history("codex1", [])
        self.fail_pause.clear()
        self.assertEqual(self.rec.run(), 0)
        self.assertTrue(self.job("up")["enabled"])

    def test_rearm_failure_preserves_boundary_and_retries_without_reply(self):
        self.healthy()
        self.fail_edit.add(("up", True))
        self.assertEqual(self.rec.run(), 1)
        boundary = self.rec.load_cycle()["monitor_since"]
        self.history("codex1", [])
        self.fail_edit.clear()
        self.assertEqual(self.rec.run(), 0)
        self.assertEqual(self.rec.load_cycle()["monitor_since"], boundary)

    def test_self_disable_retry_does_not_advance_boundary(self):
        self.healthy()
        self.fail_edit.add(("stop", False))
        self.assertEqual(self.rec.run(), 1)
        boundary = self.rec.load_cycle()["monitor_since"]
        self.history("codex1", [])
        self.fail_edit.clear()
        self.assertEqual(self.rec.run(), 0)
        self.assertEqual(self.rec.load_cycle()["monitor_since"], boundary)

    def test_unknown_status_does_not_pause_or_arm(self):
        self.healthy()
        self.fail_status.add("codex2")
        self.assertEqual(self.rec.run(), 1)
        self.assertFalse(any(method == "POST" for method, _ in self.api_calls))
        self.assertEqual(self.cli_calls, [])

    def test_old_reply_and_future_reply_cannot_stop_new_cycle(self):
        self.rec.save_cycle({"phase": "probing", "restore_since": (
            NOW - datetime.timedelta(seconds=10)).isoformat()})
        self.healthy()
        self.history("codex2", [entry("assistant", -3600)])
        self.assertEqual(self.rec.run(), 0)
        self.assertFalse(any(method == "POST" for method, _ in self.api_calls))

    def test_incomplete_restore_blocks_stop(self):
        self.healthy()
        self.enable("restore", True)
        self.assertEqual(self.rec.run(), 0)
        self.assertFalse(any(method == "POST" for method, _ in self.api_calls))

    def test_cli_success_without_persisted_readback_is_failure(self):
        self.unconfirmed_edit.add(("up", True))
        self.assertFalse(self.rec.cron_edit(self.cfg, self.job("up"), True))

    def test_stale_job_object_must_not_short_circuit_edit(self):
        stale = dict(self.job("stop"))
        self.assertTrue(self.rec.cron_edit(self.cfg, stale, False))
        self.assertTrue(self.rec.cron_edit(self.cfg, stale, True))
        self.assertEqual(self.cli_calls, [("stop", False), ("stop", True)])

    def test_duplicate_or_wrong_project_job_is_not_selected(self):
        self.jobs.append(dict(self.job("up"), id="other"))
        self.write_jobs()
        self.assertIsNone(self.rec.find_job(self.rec.UPSTREAM_MARKER))
        self.jobs.pop()
        self.job("up")["project"] = "codex2"
        self.write_jobs()
        self.assertIsNone(self.rec.find_job(self.rec.UPSTREAM_MARKER))

    def test_invalid_cycle_is_rejected(self):
        for state in ({"phase": "monitoring"}, {"phase": "invalid"},
                      {"phase": "probing", "restore_since": "invalid"},
                      {"phase": "probing", "restore_since": 17},
                      {"phase": "probing", "restore_since": NOW.isoformat(), "resumed": ["codex"]}):
            self.rec.save_cycle(state)
            with self.assertRaises(ValueError):
                self.rec.load_cycle()

    def test_old_high_load_body_and_old_failed_heartbeat_are_ignored(self):
        self.monitoring(age=60)
        self.history("codex", [entry("assistant", 90, "high demand")])
        self.assertFalse(self.up.detect(self.rec, self.cfg, NOW,
                                       NOW - datetime.timedelta(seconds=60))[0])
        self.history("codex", [entry("user", 180, PROMPT)])
        self.assertIsNone(self.up.check_failed_heartbeat(
            self.rec, [entry("user", 180, PROMPT)], NOW, PROMPT,
            NOW - datetime.timedelta(seconds=60))[0])

    def test_fresh_high_load_body_triggers_once(self):
        self.monitoring()
        self.history("codex", [entry("assistant", 60, "high demand")])
        self.assertEqual(self.up.run(self.rec), 0)
        self.assertTrue(self.job("restore")["enabled"])
        self.assertFalse(self.job("up")["enabled"])
        self.assertEqual(self.rec.load_cycle()["phase"], "triggered")

    def test_failed_heartbeat_only_triggers_with_high_load_log(self):
        self.monitoring()
        self.history("codex", [entry("user", 180, PROMPT)])
        timestamp = (NOW - datetime.timedelta(seconds=170)).isoformat()
        for error, expected in (("rate limit exceeded", False), ("429 Too Many Requests", False),
                                ("get_channel_failed", False), ("400 bad request", False),
                                ("high demand temporary errors", True)):
            Path(self.up.CC_LOG).write_text(
                'time=' + timestamp + ' level=ERROR msg="agent error" error="' + error + '"\n',
                encoding="utf-8")
            self.assertEqual(self.up.detect(self.rec, self.cfg, NOW)[0], expected, error)

    def test_human_message_and_recent_inflight_heartbeat_not_errors(self):
        for history in ([entry("user", 180, "human task")], [entry("user", 30, PROMPT)]):
            self.assertIsNone(self.up.check_failed_heartbeat(self.rec, history, NOW, PROMPT)[0])

    def test_rate_limit_body_not_high_load(self):
        for error in ("rate limit", "429 Too Many Requests", "exceeded retry limit", "400",
                      "get_channel_failed", "resource temporarily blocked"):
            self.assertFalse(self.up.is_high_load(error), error)

    def test_some_heartbeats_running_prevents_duplicate_restore(self):
        self.monitoring()
        self.paused["codex4"] = False
        self.history("codex", [entry("assistant", 60, "high demand")])
        self.assertEqual(self.up.run(self.rec), 0)
        self.assertFalse(self.job("restore")["enabled"])

    def test_upstream_self_disable_failure_only_retries_cleanup(self):
        self.monitoring()
        self.history("codex", [entry("assistant", 60, "high demand")])
        self.fail_edit.add(("up", False))
        self.assertEqual(self.up.run(self.rec), 1)
        self.fail_edit.clear()
        self.history("codex", [])
        self.assertEqual(self.up.run(self.rec), 0)
        self.assertEqual(self.cli_calls.count(("restore", True)), 1)
        self.assertFalse(self.job("up")["enabled"])

    def test_failed_restore_arm_retries_confirmed_trigger_without_new_hit(self):
        self.monitoring()
        self.history("codex", [entry("assistant", 60, "high demand")])
        self.fail_edit.add(("restore", True))
        self.assertEqual(self.up.run(self.rec), 1)
        self.history("codex", [])
        self.fail_edit.clear()
        self.assertEqual(self.up.run(self.rec), 0)
        self.assertTrue(self.job("restore")["enabled"])

    def test_partial_resume_retries_without_repeating_rotation(self):
        self.stopped()
        self.enable("restore", True)
        self.fail_resume.add("codex4")
        self.assertEqual(self.restore.run(self.rec), 1)
        self.assertTrue(self.job("restore")["enabled"])
        self.assertFalse(self.job("stop")["enabled"])
        self.assertEqual(self.rot.rotate_one.call_count, 9)
        self.fail_resume.clear()
        self.assertEqual(self.restore.run(self.rec), 0)
        self.assertEqual(self.rot.rotate_one.call_count, 9)
        self.assertTrue(self.job("stop")["enabled"])
        self.assertFalse(self.job("restore")["enabled"])
        self.assertEqual(self.rec.load_cycle()["phase"], "probing")

    def test_stop_arm_failure_retries_without_repeating_rotation(self):
        self.stopped()
        self.enable("restore", True)
        self.fail_edit.add(("stop", True))
        self.assertEqual(self.restore.run(self.rec), 1)
        self.fail_edit.clear()
        self.assertEqual(self.restore.run(self.rec), 0)
        self.assertEqual(self.rot.rotate_one.call_count, 9)

    def test_restore_self_disable_failure_retries_without_repeating_rotation(self):
        self.stopped()
        self.enable("restore", True)
        self.fail_edit.add(("restore", False))
        self.assertEqual(self.restore.run(self.rec), 1)
        self.fail_edit.clear()
        self.assertEqual(self.restore.run(self.rec), 0)
        self.assertEqual(self.rot.rotate_one.call_count, 9)

    def test_rotation_failure_does_not_resume_that_project(self):
        self.stopped()
        self.enable("restore", True)
        self.rot.rotate_one.side_effect = lambda n: (1, False) if n == "codex4" else (0, False)
        self.assertEqual(self.restore.run(self.rec), 1)
        self.assertTrue(self.paused["codex4"])
        self.assertNotIn("codex4", self.rec.load_cycle()["reset_done"])

    def real_rotation(self):
        rot = module("rotate-codex-session")
        rot.DATA_DIR = str(self.data)
        rot.ARCHIVE_ROOT = str(self.root / "archive")
        rot.LOG = str(self.root / "rotate.log")
        rot.DRY = False
        self.start(patch.object(rot, "log", Mock()))
        self.start(patch.object(rot, "codex_project", side_effect=lambda name: (
            self.rec.project_cfg(self.cfg, name))))
        self.start(patch.object(rot, "codex_busy", return_value=None))
        return rot

    def rollout(self, name="codex4"):
        home = Path(self.rec.project_cfg(self.cfg, name)["agent"]["options"]["codex_home"])
        folder = home / "sessions/2026/10/25"
        folder.mkdir(parents=True)
        path = folder / "rollout-test-thread.jsonl"
        path.write_text('{"type":"session_meta"}\n{"type":"event_msg"}\n', encoding="utf-8")
        self.history(name, [])
        suffix = hashlib.sha256(str(self.root).encode()).hexdigest()[:8]
        state_path = self.data / "sessions" / (name + "_" + suffix + ".json")
        state = json.loads(state_path.read_text(encoding="utf-8"))
        state["sessions"]["session"]["agent_session_id"] = "test-thread"
        state_path.write_text(json.dumps(state), encoding="utf-8")
        return path

    def test_real_rotation_archives_before_truncating(self):
        rot = self.real_rotation()
        path = self.rollout()
        original = path.read_bytes()
        self.assertEqual(rot.rotate_one("codex4"), (0, False))
        self.assertEqual(path.read_bytes(), original.splitlines(keepends=True)[0])
        backups = list((self.root / "archive").rglob("*.jsonl"))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_bytes(), original)

    def test_real_backup_failure_must_not_mark_reset_done_or_resume(self):
        rot = self.real_rotation()
        path = self.rollout()
        original = path.read_bytes()
        self.stopped()
        self.enable("restore", True)
        self.restore.load_rotate.return_value = rot
        original_copy = rot.shutil.copy2
        copier = self.start(patch.object(rot.shutil, "copy2", side_effect=OSError("backup unavailable")))
        self.assertEqual(self.restore.run(self.rec), 1)
        self.assertEqual(path.read_bytes(), original)
        self.assertTrue(self.paused["codex4"])
        self.assertNotIn("codex4", self.rec.load_cycle()["reset_done"])
        copier.side_effect = original_copy
        self.assertEqual(self.restore.run(self.rec), 0)
        self.assertFalse(self.paused["codex4"])
        self.assertIn("codex4", self.rec.load_cycle()["reset_done"])
        self.assertEqual(path.read_bytes(), original.splitlines(keepends=True)[0])
        self.assertEqual(len(list((self.root / "archive").rglob("*.jsonl"))), 1)

    def test_real_invalid_thread_metadata_preserves_original(self):
        rot = self.real_rotation()
        path = self.rollout()
        path.write_text('{"type":"event_msg"}\n{"type":"event_msg"}\n', encoding="utf-8")
        original = path.read_bytes()
        self.stopped()
        self.enable("restore", True)
        self.restore.load_rotate.return_value = rot
        self.assertEqual(self.restore.run(self.rec), 1)
        self.assertEqual(path.read_bytes(), original)
        self.assertTrue(self.paused["codex4"])
        self.assertFalse((self.root / "archive").exists())

    def test_actual_import_paths_and_flags(self):
        upstream = module("codex-upstream-watch")
        upstream.WATCH_SCRIPT = str(SCRIPTS / "codex-recovery-watch.py")
        upstream.DRY = True
        upstream.STATUS_ONLY = True
        loaded = upstream.load_watch()
        self.assertTrue(loaded.DRY)
        self.assertTrue(loaded.STATUS_ONLY)
        self.assertTrue(callable(loaded.cycle_lock))
        restore = module("codex-restore-heartbeat")
        restore.WATCH_PY = str(SCRIPTS / "codex-recovery-watch.py")
        restore.ROTATE_PY = str(SCRIPTS / "rotate-codex-session.py")
        restore.DRY = True
        self.assertTrue(restore.load_watch().DRY)
        self.assertTrue(callable(restore.load_rotate().rotate_one))

    def test_tencent_root_and_probe_label_are_configurable(self):
        with patch.dict(os.environ, {"CC_CONNECT_DIR": str(self.root),
                                     "CC_PROBE_LABEL": "Tencent fixture probe"}):
            for name in ("codex-recovery-watch", "codex-upstream-watch", "codex-restore-heartbeat"):
                m = module(name)
                self.assertEqual(Path(m.CONFIG), self.root / "config.toml")
                self.assertEqual(Path(m.DATA_DIR), self.root / "data")
                if hasattr(m, "PROBE_LABEL"):
                    self.assertEqual(m.PROBE_LABEL, "Tencent fixture probe")

    def test_real_loggers_in_readonly_modes_do_not_create_logs(self):
        for name in ("codex-recovery-watch", "codex-upstream-watch", "codex-restore-heartbeat"):
            m = module(name)
            m.LOG = str(self.root / (name + ".log"))
            for flag in ("DRY", "STATUS_ONLY"):
                m.DRY = m.STATUS_ONLY = False
                setattr(m, flag, True)
                with patch("builtins.print"):
                    m.log("read only")
                self.assertFalse(Path(m.LOG).exists())

    def test_status_unknown_is_not_reported_as_all_stopped(self):
        self.rec.STATUS_ONLY = True
        self.fail_status.add("codex4")
        self.rec.run()
        messages = [str(c.args[0]) for c in self.rec.log.call_args_list]
        self.assertTrue(any("未知" in m for m in messages))
        self.assertFalse(any("全部已停" in m for m in messages))

    def test_busy_project_preserves_original_skip_policy(self):
        self.stopped()
        self.enable("restore", True)
        self.rot.codex_busy.return_value = "123"
        self.assertEqual(self.restore.run(self.rec), 0)
        self.assertEqual(self.rot.rotate_one.call_count, 0)
        self.assertEqual(self.rec.load_cycle()["skipped"], self.rec.PROJECTS)

    def test_two_complete_cycles(self):
        for _ in range(2):
            self.healthy()
            if self.rec.load_cycle().get("phase") == "probing":
                since = self.rec.parse_ts(self.rec.load_cycle()["restore_since"])
                self.history("codex1", [{"role": "assistant", "content": "normal response",
                                          "timestamp": (since + datetime.timedelta(
                                              microseconds=1)).isoformat()}])
            self.assertEqual(self.rec.run(), 0)
            boundary = self.rec.parse_ts(self.rec.load_cycle()["monitor_since"])
            self.history("codex", [{"role": "assistant", "content": "high demand",
                                     "timestamp": (boundary + datetime.timedelta(
                                         microseconds=1)).isoformat()}])
            self.assertEqual(self.up.run(self.rec), 0)
            self.assertEqual(self.restore.run(self.rec), 0)
            self.assertFalse(any(self.paused.values()))
            self.assertTrue(self.job("stop")["enabled"])
            self.assertFalse(self.job("restore")["enabled"])
            self.assertFalse(self.job("up")["enabled"])
        self.assertEqual(self.rot.rotate_one.call_count, 18)

    def test_dry_run_and_status_are_non_mutating(self):
        self.healthy()
        before = {p.relative_to(self.root): p.read_bytes() for p in self.root.rglob("*") if p.is_file()}
        for name in ("DRY", "STATUS_ONLY"):
            for m in (self.rec, self.up, self.restore):
                setattr(m, name, True)
            for m in (self.rec, self.up, self.restore):
                self.assertEqual(m.main(), 0)
            for m in (self.rec, self.up, self.restore):
                setattr(m, name, False)
        after = {p.relative_to(self.root): p.read_bytes() for p in self.root.rglob("*") if p.is_file()}
        self.assertEqual(before, after)
        self.assertEqual(self.cli_calls, [])
        self.assertFalse(any(method == "POST" for method, _ in self.api_calls))

    @unittest.skipUnless(os.name == "posix", "Linux flock integration")
    def test_shared_lock_skips_overlapping_task(self):
        with self.rec.cycle_lock() as first:
            with self.rec.cycle_lock() as second:
                self.assertTrue(first)
                self.assertFalse(second)


if __name__ == "__main__":
    unittest.main(verbosity=2)
