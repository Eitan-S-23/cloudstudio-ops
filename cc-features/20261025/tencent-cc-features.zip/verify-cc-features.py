#!/usr/bin/env python3
"""只读核查新版自愈脚本、种子以及 /notify 静态特征；卡片仍须飞书实测。"""

import argparse
import ast
import json
from pathlib import Path

REQUIRED = {
    "codex-recovery-watch.py": {"load_cycle", "save_cycle", "cycle_lock", "cron_edit"},
    "codex-upstream-watch.py": {"run", "main", "detect"},
    "codex-restore-heartbeat.py": {"run", "main", "rotate_checked"},
}
FILES = (*REQUIRED, "rotate-codex-session.py", "codex-stop-heartbeat.py", "codex-new-session.py")


def verify_scripts(root: Path):
    for name in FILES:
        path = root / name
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=name)
        functions = {node.name for node in tree.body
                     if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        missing = REQUIRED.get(name, set()) - functions
        if missing:
            raise ValueError(f"{name} 缺少新版契约: {', '.join(sorted(missing))}")
    for name in ("codex-upstream-watch.py", "codex-restore-heartbeat.py"):
        text = (root / name).read_text(encoding="utf-8")
        if "mod.cycle_lock()" not in text or "mod.load_cycle()" not in text:
            raise ValueError(f"{name} 没有接入共享轮次与锁")
    for name in FILES:
        if "华为服务器-codex" in (root / name).read_text(encoding="utf-8"):
            raise ValueError(f"{name} 残留华为展示名，未完成腾讯适配")


def verify_template(path: Path):
    jobs = json.loads(path.read_text(encoding="utf-8"))
    if len(jobs) != 13 or sum(job.get("enabled") is True for job in jobs) != 10:
        raise ValueError("种子应为 13 条：10 轮换启用 + 3 自愈停用")
    if any(job.get("session_key") for job in jobs):
        raise ValueError("公开/通用部署模板不得含真实会话键")
    if len({job["id"] for job in jobs}) != 13:
        raise ValueError("种子任务 ID 重复")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/cc-connect"))
    parser.add_argument("--scripts-only", action="store_true", help="本地资料检查，不检查二进制")
    parser.add_argument("--template", type=Path, help="可选：检查脱敏种子")
    parser.add_argument("--binary", type=Path, help="默认检查 root/cc-connect，只读，不运行程序")
    args = parser.parse_args()
    try:
        verify_scripts(args.root)
        if args.template:
            verify_template(args.template)
        print("新版自愈脚本契约检查通过")
        if not args.scripts_only:
            binary = args.binary or args.root / "cc-connect"
            if b"/notify" not in binary.read_bytes():
                raise ValueError("二进制未检出 /notify 静态特征；不得声称已跟进通知功能")
            print("已检出 /notify 静态文本；仍须飞书实测卡片、on/off 和逐机器人隔离")
        return 0
    except (OSError, ValueError, SyntaxError, KeyError, TypeError) as exc:
        print(f"检查失败: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
